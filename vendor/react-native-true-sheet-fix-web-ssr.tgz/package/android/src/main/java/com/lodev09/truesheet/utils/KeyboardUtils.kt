package com.lodev09.truesheet.utils

import android.content.Context
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsAnimationCompat
import androidx.core.view.WindowInsetsCompat
import com.facebook.react.uimanager.ThemedReactContext

object KeyboardUtils {

  /**
   * Checks if the soft keyboard is currently visible.
   */
  fun isKeyboardVisible(reactContext: ThemedReactContext): Boolean {
    val rootView = reactContext.currentActivity?.window?.decorView?.rootView ?: return false
    return isKeyboardVisible(rootView)
  }

  fun isKeyboardVisible(view: View): Boolean {
    val insets = ViewCompat.getRootWindowInsets(view) ?: return false
    return insets.isVisible(WindowInsetsCompat.Type.ime())
  }

  /**
   * Dismisses the soft keyboard if currently shown.
   */
  fun dismiss(reactContext: ThemedReactContext) {
    val rootView = reactContext.currentActivity?.window?.decorView?.rootView ?: return
    dismiss(rootView, null)
  }

  /**
   * Dismisses the soft keyboard with an optional callback when the animation completes.
   */
  fun dismiss(view: View, onComplete: (() -> Unit)?) {
    if (!isKeyboardVisible(view)) {
      onComplete?.invoke()
      return
    }

    val imm = view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    val focusedView = view.rootView.findFocus()

    // A keyboard can stay up with nothing focused, e.g. a blur that lands after focus was restored,
    // so hide it through the window instead of treating it as already hidden.
    if (focusedView == null) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        view.windowInsetsController?.hide(WindowInsets.Type.ime())
      } else {
        imm?.hideSoftInputFromWindow(view.windowToken, 0)
      }
      onComplete?.invoke()
      return
    }

    if (onComplete != null) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        ViewCompat.setWindowInsetsAnimationCallback(
          view,
          object : WindowInsetsAnimationCompat.Callback(DISPATCH_MODE_CONTINUE_ON_SUBTREE) {
            override fun onProgress(insets: WindowInsetsCompat, runningAnimations: List<WindowInsetsAnimationCompat>): WindowInsetsCompat =
              insets

            override fun onEnd(animation: WindowInsetsAnimationCompat) {
              ViewCompat.setWindowInsetsAnimationCallback(view, null)
              onComplete()
            }
          }
        )
      } else {
        view.postDelayed({ onComplete() }, 120)
      }
    }

    imm?.hideSoftInputFromWindow(focusedView.windowToken, 0)
  }

  /**
   * Shows the soft keyboard for the given view.
   */
  fun show(view: View) {
    val imm = view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    imm?.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
  }

  /**
   * Gets the current keyboard height from window insets.
   */
  fun getKeyboardHeight(view: View): Int {
    val insets = ViewCompat.getRootWindowInsets(view)
    return insets?.getInsets(WindowInsetsCompat.Type.ime())?.bottom ?: 0
  }
}

import { type ReactNode, type RefObject } from 'react';
import type { TrueSheetMethods, TrueSheetStaticMethods } from './TrueSheet.types';
export declare const PORTAL_CONTAINER_ATTRIBUTE = "data-true-sheet-portal";
export interface SheetHandle {
    methods: TrueSheetMethods;
    dismissQuietly: (animated?: boolean) => Promise<void>;
}
type SheetRef = RefObject<SheetHandle | null>;
type NodeRef = RefObject<HTMLDivElement | null>;
interface StackEntry {
    ref: SheetRef;
    nodeRef: NodeRef;
    isFormSheetRef: RefObject<boolean>;
}
export interface TrueSheetProviderProps {
    children: ReactNode;
}
export declare function TrueSheetProvider({ children }: TrueSheetProviderProps): import("react/jsx-runtime").JSX.Element;
export declare function usePortalContainer(): HTMLElement | null;
export declare function useTrueSheet(): TrueSheetStaticMethods;
export declare function useRegisterSheet(name: string | undefined, ref: SheetRef): void;
/**
 * Registers the sheet in the open stack while `isOpen` is true and returns
 * live data used by each sheet to render stacked visuals and dismiss children.
 */
export declare function useSheetStack(ref: SheetRef, nodeRef: NodeRef, isOpen: boolean, isFormSheet: boolean): {
    descendants: readonly StackEntry[];
    isNested: boolean;
    dismissAbove: (animated?: boolean) => Promise<void>;
};
export {};
//# sourceMappingURL=TrueSheetProvider.web.d.ts.map
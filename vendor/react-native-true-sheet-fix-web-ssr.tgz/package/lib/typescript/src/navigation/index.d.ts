import { type StandardNavigationTypeBagBase } from '@react-navigation/native';
import type { TrueSheetActionHelpers, TrueSheetNavigationOptions, TrueSheetNavigationEventMap, TrueSheetNavigationState, TrueSheetRouterOptions } from './types';
export interface TrueSheetNavigationTypeBag extends StandardNavigationTypeBagBase {
    State: TrueSheetNavigationState<this['ParamList']>;
    ActionHelpers: TrueSheetActionHelpers<this['ParamList']>;
    ScreenOptions: TrueSheetNavigationOptions;
    EventMap: TrueSheetNavigationEventMap;
    RouterOptions: TrueSheetRouterOptions;
}
/**
 * Creates a TrueSheet navigator.
 *
 * @example
 * ```tsx
 * const Sheet = createTrueSheetNavigator();
 *
 * function App() {
 *   return (
 *     <Sheet.Navigator>
 *       <Sheet.Screen name="Home" component={HomeScreen} />
 *       <Sheet.Screen
 *         name="Details"
 *         component={DetailsSheet}
 *         options={{ detents: [0.5, 1] }}
 *       />
 *     </Sheet.Navigator>
 *   );
 * }
 * ```
 */
export declare const createTrueSheetNavigator: import("@react-navigation/native").StandardNavigationCreateNavigator<TrueSheetNavigationTypeBag, {}>;
/**
 * Creates a screen configuration for the static API.
 */
export declare const createTrueSheetScreen: import("@react-navigation/core").StaticScreenFactory<TrueSheetNavigationTypeBag & {
    ParamList: import("@react-navigation/routers").ParamListBase;
    NavigatorID: string | undefined;
    Navigator: import("react").ComponentType<{}>;
}>;
export { TrueSheetActions, type TrueSheetActionType } from './actions';
export { createTrueSheetRouter } from './createTrueSheetRouter';
export { useTrueSheetNavigation } from './useTrueSheetNavigation';
export type { DetentInfoEventPayload, PositionChangeEventPayload } from '../TrueSheet.types';
export type { StackRouterFactory, TrueSheetNavigationEventMap, TrueSheetNavigationHelpers, TrueSheetNavigationOptions, TrueSheetNavigationProp, TrueSheetNavigationState, TrueSheetRouterOptions, TrueSheetScreenProps, } from './types';
//# sourceMappingURL=index.d.ts.map
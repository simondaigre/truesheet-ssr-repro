import { type TrueSheetActionType } from './actions';
import type { TrueSheetRouter, TrueSheetRouterFactory, TrueSheetRouterOptions } from './types';
type SheetRoute = {
    key: string;
    name: string;
    closing?: boolean;
    dismissing?: boolean;
    resizeIndex?: number;
    resizeKey?: number;
};
type SheetState = {
    key: string;
    index: number;
    routes: SheetRoute[];
};
/**
 * Index of the route a `RESIZE` targets: the dispatching screen, else the focused route.
 */
export declare const getResizeRouteIndex: (state: SheetState, action: {
    source?: string;
    target?: string;
}) => number;
/**
 * Reduces the sheet-specific actions shared by every router flavour.
 * Returns `undefined` for actions the base `StackRouter` should handle.
 */
export declare const getTrueSheetStateForAction: <State extends SheetState>(state: State, action: TrueSheetActionType) => State | null | undefined;
/**
 * Reduces an action that targets the base route by name. React Navigation 7 adds another base
 * route for a `PUSH`, a `REPLACE` or a `NAVIGATE` without `pop`, which presents the base screen
 * as a sheet, and this router's `POP_TO` drops the params and nested state. This goes back to it
 * instead: `getPoppedState` reduces the action as a `NAVIGATE` with `pop` (a `PUSH` ignores
 * `pop`) to update the base route (params, nested state), then the sheets above it are dismissed.
 * Returns `undefined` for other actions, a `REPLACE` with no sheet (it swaps the base route), or
 * when the base router doesn't land on the base route.
 */
export declare const getStateForNavigateToBase: <State extends SheetState>(state: State, action: TrueSheetActionType, getPoppedState: (action: TrueSheetActionType) => State | null | undefined) => State | undefined;
export declare const createTrueSheetRouter: (stackRouter: TrueSheetRouterFactory) => (routerOptions: TrueSheetRouterOptions) => TrueSheetRouter;
export {};
//# sourceMappingURL=createTrueSheetRouter.d.ts.map
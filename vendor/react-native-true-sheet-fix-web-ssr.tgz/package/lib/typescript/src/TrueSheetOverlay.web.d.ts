import { type ViewProps } from 'react-native';
/**
 * Renders its children in a layer above every presented sheet — for
 * toasts, dialogs, and other content a sheet must not cover.
 * Fills the window; touches that miss its children pass through to the views beneath.
 */
export declare const TrueSheetOverlay: ({ style, ...rest }: ViewProps) => import("react").ReactPortal | null;
//# sourceMappingURL=TrueSheetOverlay.web.d.ts.map
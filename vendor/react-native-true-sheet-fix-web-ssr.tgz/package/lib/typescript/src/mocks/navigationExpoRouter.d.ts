import type { ParamListBase } from '../navigation/expo-router/base-types';
import type { TrueSheetNavigationProp } from '../navigation/expo-router/types';
import { TrueSheetActions } from './navigation';
/**
 * Mock Sheet layout for testing.
 * Import from '@lodev09/react-native-true-sheet/navigation/expo-router/mock' in your test setup.
 */
export declare const Sheet: jest.Mock<import("react").ReactNode, [{
    children: React.ReactNode;
}], any> & {
    Screen: jest.Mock<null, [], any>;
    Protected: jest.Mock<null, [], any>;
};
/**
 * Mock useTrueSheetNavigation hook for testing.
 */
export declare const useTrueSheetNavigation: jest.Mock<TrueSheetNavigationProp<ParamListBase>, [], any>;
export { TrueSheetActions };
export type { TrueSheetActionType } from '../navigation/actions';
export type { DetentInfoEventPayload, PositionChangeEventPayload } from '../TrueSheet.types';
export type { TrueSheetNavigationEventMap, TrueSheetNavigationHelpers, TrueSheetNavigationOptions, TrueSheetNavigationProp, TrueSheetNavigationState, TrueSheetScreenProps, } from '../navigation/expo-router/types';
//# sourceMappingURL=navigationExpoRouter.d.ts.map
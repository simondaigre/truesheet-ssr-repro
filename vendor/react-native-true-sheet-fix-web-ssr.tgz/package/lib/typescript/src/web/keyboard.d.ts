import type { KeyboardViewport } from './vaul/types';
/**
 * Tracks the visual viewport while a soft keyboard shrinks it. iOS Safari and
 * Chrome (default `interactive-widget`) keep the layout viewport — and every
 * fixed element — full height under the keyboard, so the sheet has to be laid
 * out against the visual viewport instead.
 */
export declare function useKeyboardViewport(enabled: boolean): KeyboardViewport | undefined;
/**
 * Scrolls the focused field in `container` back above its scroll parent's
 * bottom edge, clearing a floating footer. The browser only reveals it on
 * focus — before the sheet fits above the keyboard.
 */
export declare function revealFocusedElement(container: HTMLElement): void;
//# sourceMappingURL=keyboard.d.ts.map
export declare const TRANSITIONS: {
    DURATION: number;
    EASE: number[];
};
export declare const VELOCITY_THRESHOLD = 0.4;
export declare const DEFAULT_PEEK_HEIGHT = 150;
export declare const CLOSE_THRESHOLD = 0.25;
export declare const SHORT_DISMISS_VELOCITY = 0.125;
export declare const SHORT_DISMISS_DISTANCE = 56;
export declare const DISMISS_ATTEMPT_THRESHOLD = 24;
export declare const SCROLL_LOCK_TIMEOUT = 100;
export declare const BORDER_RADIUS = 8;
export declare const NESTED_DISPLACEMENT = 16;
export declare const WINDOW_TOP_OFFSET = 26;
export declare const DRAG_CLASS = "vaul-dragging";
//# sourceMappingURL=constants.d.ts.map
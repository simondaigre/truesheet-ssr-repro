export declare const FOOTER_INSET = "--truesheet-footer-inset";
interface SheetLayoutOptions {
    drawer: HTMLElement;
    layout: HTMLElement;
    getContent: () => HTMLElement | null;
    getHeader: () => HTMLElement | null;
    getFooter: () => HTMLElement | null;
    getScrollable: () => HTMLElement | null;
    absoluteHeader: boolean;
    absoluteFooter: boolean;
    footerInsetAdjustment: boolean;
    measureContent: boolean;
    onHeightChange: (height: number) => void;
}
export declare function observeSheetLayout({ drawer, layout, getContent, getHeader, getFooter, getScrollable, absoluteHeader, absoluteFooter, footerInsetAdjustment, measureContent, onHeightChange, }: SheetLayoutOptions): {
    measure: () => void;
    disconnect: () => void;
};
export {};
//# sourceMappingURL=layout.d.ts.map
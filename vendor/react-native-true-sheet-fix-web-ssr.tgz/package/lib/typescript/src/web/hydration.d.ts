/**
 * False on the server and while hydrating a server-rendered page, true once hydrated (and in
 * client-only apps), when the window can be read without the render differing from the server's.
 */
export declare const useIsHydrated: () => boolean;
//# sourceMappingURL=hydration.d.ts.map
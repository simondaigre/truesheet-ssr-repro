import type { DetentBackground } from './TrueSheet.types';
export declare function normalizeDetentBackground(entry: DetentBackground | null | undefined): {
    color: import("react-native").ColorValue;
    blur?: never;
} | {
    blur: import("./TrueSheet.types").BackgroundBlur;
    color?: never;
} | null | undefined;
export declare function getDetentBackgroundIndex(height: number, detentHeights: readonly number[], displayedIndex: number): number;
//# sourceMappingURL=detentBackgrounds.d.ts.map
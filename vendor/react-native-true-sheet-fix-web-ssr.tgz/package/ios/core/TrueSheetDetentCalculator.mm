//
//  Created by Jovanni Lo (@lodev09)
//  Copyright (c) 2024-present. All rights reserved.
//
//  This source code is licensed under the MIT license found in the
//  LICENSE file in the root directory of this source tree.
//

#import "TrueSheetDetentCalculator.h"

@implementation TrueSheetDetentCalculator {
  NSMutableArray<NSNumber *> *_resolvedDetentOffsets;
}

#pragma mark - Public Methods

- (CGFloat)detentValueForIndex:(NSInteger)index {
  NSArray<NSNumber *> *detents = self.delegate.detents;
  if (index >= 0 && index < (NSInteger)detents.count) {
    CGFloat value = [detents[index] doubleValue];
    if (value == -1) {
      return [self autoHeightForKeyboardHeight:0] / self.delegate.screenHeight;
    }
    if (value == -2) {
      return [self peekHeight] / self.delegate.screenHeight;
    }
    return value;
  }
  return 0;
}

- (CGFloat)autoHeightForKeyboardHeight:(CGFloat)keyboardHeight {
  // An absolute (floating) header or footer overlaps the content, so it contributes no height —
  // unless the footer pads the scrollable, then the content ends above it like a relative footer
  CGFloat headerHeight = self.delegate.absoluteHeader ? 0 : [self.delegate.headerHeight floatValue];
  BOOL floatingFooter = self.delegate.absoluteFooter && !self.delegate.footerInsetAdjustment;
  CGFloat footerHeight = floatingFooter ? 0 : [self.delegate.footerHeight floatValue];
  if (self.delegate.absoluteFooter && !floatingFooter && !self.delegate.footerAvoidsKeyboard) {
    footerHeight -= MIN(keyboardHeight, MAX(0, footerHeight - self.delegate.appliedFooterBottomInset));
  }
  return [self.delegate.contentHeight floatValue] + headerHeight + footerHeight;
}

- (CGFloat)peekHeight {
  // A relative footer is laid out below the content, so it's pushed off-screen
  // at the peek detent and contributes no height
  CGFloat footerHeight = self.delegate.absoluteFooter ? [self.delegate.footerHeight floatValue] : 0;
  CGFloat height =
    [self.delegate.headerHeight floatValue] + footerHeight + [self.delegate.peekContentHeight floatValue];
  return height > 0 ? height : 150;
}

- (void)learnOffsetForDetentIndex:(NSInteger)index {
  if (index < 0 || !_resolvedDetentHeights || index >= (NSInteger)_resolvedDetentHeights.count) {
    return;
  }

  CGFloat actualHeight = self.delegate.screenHeight - self.delegate.currentPosition;
  CGFloat resolverHeight = [_resolvedDetentHeights[index] doubleValue];
  // Always update — system offset can change between detent transitions
  if (resolverHeight > 0 && actualHeight > 0) {
    _resolvedDetentOffsets[index] = @(actualHeight - resolverHeight);
  }
}

- (CGFloat)resolvedHeightForIndex:(NSInteger)index {
  if (_resolvedDetentHeights && index >= 0 && index < (NSInteger)_resolvedDetentHeights.count) {
    CGFloat h = [_resolvedDetentHeights[index] doubleValue];
    if (h > 0) {
      // Use per-detent offset if learned, otherwise find any known offset
      CGFloat offset = [self offsetForIndex:index];
      return h + offset;
    }
  }

  CGFloat detentValue = [self detentValueForIndex:index];
  if (_maxDetentHeight > 0) {
    return detentValue * _maxDetentHeight;
  }
  return detentValue * self.delegate.screenHeight;
}

- (CGFloat)learnedOffsetForIndex:(NSInteger)index {
  if (index >= 0 && index < (NSInteger)_resolvedDetentOffsets.count) {
    return [_resolvedDetentOffsets[index] doubleValue];
  }
  return 0;
}

- (void)assumeOffset:(CGFloat)offset forIndex:(NSInteger)index {
  if (index >= 0 && index < (NSInteger)_resolvedDetentOffsets.count &&
      fabs([_resolvedDetentOffsets[index] doubleValue] - offset) > 1) {
    _resolvedDetentOffsets[index] = @(offset);
  }
}

- (CGFloat)offsetForIndex:(NSInteger)index {
  // Use this detent's own offset if available
  CGFloat learnedOffset = [self learnedOffsetForIndex:index];
  if (learnedOffset != 0)
    return learnedOffset;

  // Fall back to any known offset
  for (NSInteger i = 0; i < (NSInteger)_resolvedDetentOffsets.count; i++) {
    CGFloat offset = [_resolvedDetentOffsets[i] doubleValue];
    if (offset != 0)
      return offset;
  }

  return 0;
}

- (NSInteger)backgroundIndexForPosition:(CGFloat)position displayedIndex:(NSInteger)displayedIndex {
  NSInteger count = self.delegate.detents.count;
  if (count == 0)
    return -1;

  CGFloat height = self.delegate.screenHeight - position;
  NSInteger nextIndex = MAX(0, MIN(displayedIndex, count - 1));
  CGFloat distance = fabs(height - [self resolvedHeightForIndex:nextIndex]);
  for (NSInteger index = 0; index < count; index++) {
    CGFloat nextDistance = fabs(height - [self resolvedHeightForIndex:index]);
    if (nextDistance < distance) {
      nextIndex = index;
      distance = nextDistance;
    }
  }
  return nextIndex;
}

- (BOOL)findSegmentForPosition:(CGFloat)position outIndex:(NSInteger *)outIndex outProgress:(CGFloat *)outProgress {
  NSArray<NSNumber *> *detents = self.delegate.detents;
  NSInteger count = detents.count;
  if (count == 0) {
    *outIndex = -1;
    *outProgress = 0;
    return NO;
  }

  CGFloat screenHeight = self.delegate.screenHeight;
  CGFloat sheetHeight = screenHeight - position;
  CGFloat firstHeight = [self resolvedHeightForIndex:0];

  // Below first detent - interpolating toward closed
  if (sheetHeight < firstHeight) {
    *outIndex = -1;
    *outProgress = firstHeight > 0 ? (firstHeight - sheetHeight) / firstHeight : 0;
    return NO;
  }

  // Single detent
  if (count == 1) {
    *outIndex = 0;
    *outProgress = 0;
    return NO;
  }

  CGFloat lastHeight = [self resolvedHeightForIndex:count - 1];

  // Above last detent
  if (sheetHeight > lastHeight) {
    *outIndex = count - 1;
    *outProgress = 0;
    return NO;
  }

  // Between detents
  for (NSInteger i = 0; i < count - 1; i++) {
    CGFloat h = [self resolvedHeightForIndex:i];
    CGFloat nextH = [self resolvedHeightForIndex:i + 1];

    if (sheetHeight >= h && sheetHeight <= nextH) {
      CGFloat range = nextH - h;
      *outIndex = i;
      *outProgress = range > 0 ? (sheetHeight - h) / range : 0;
      return YES;
    }
  }

  *outIndex = count - 1;
  *outProgress = 0;
  return NO;
}

- (CGFloat)interpolatedIndexForPosition:(CGFloat)position {
  NSInteger index;
  CGFloat progress;
  BOOL found = [self findSegmentForPosition:position outIndex:&index outProgress:&progress];

  if (!found) {
    if (index == -1) {
      return -progress;
    }
    return index;
  }

  return index + fmax(0, fmin(1, progress));
}

- (CGFloat)interpolatedDetentForPosition:(CGFloat)position {
  NSInteger index;
  CGFloat progress;
  BOOL found = [self findSegmentForPosition:position outIndex:&index outProgress:&progress];

  if (!found) {
    if (index == -1) {
      CGFloat firstDetent = [self detentValueForIndex:0];
      return fmax(0, firstDetent * (1 - progress));
    }
    return [self detentValueForIndex:index];
  }

  CGFloat detent = [self detentValueForIndex:index];
  CGFloat nextDetent = [self detentValueForIndex:index + 1];
  return detent + progress * (nextDetent - detent);
}

- (void)clearResolvedHeights {
  [_resolvedDetentHeights removeAllObjects];
  [_resolvedDetentOffsets removeAllObjects];
}

- (void)setDetentCount:(NSInteger)count {
  _resolvedDetentHeights = [NSMutableArray arrayWithCapacity:count];
  _resolvedDetentOffsets = [NSMutableArray arrayWithCapacity:count];
  for (NSInteger i = 0; i < count; i++) {
    [_resolvedDetentHeights addObject:@(0)];
    [_resolvedDetentOffsets addObject:@(0)];
  }
}

@end

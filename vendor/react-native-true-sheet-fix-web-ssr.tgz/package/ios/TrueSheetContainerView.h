//
//  Created by Jovanni Lo (@lodev09)
//  Copyright (c) 2024-present. All rights reserved.
//
//  This source code is licensed under the MIT license found in the
//  LICENSE file in the root directory of this source tree.
//

#ifdef RCT_NEW_ARCH_ENABLED

#import <React/RCTViewComponentView.h>
#import <UIKit/UIKit.h>
#import <react/renderer/components/TrueSheetSpec/Props.h>

NS_ASSUME_NONNULL_BEGIN

@interface ScrollableOptions : NSObject

@property (nonatomic, assign) facebook::react::TrueSheetViewContentInsetAdjustment contentInsetAdjustment;
@property (nonatomic, assign) CGFloat keyboardScrollOffset;
@property (nonatomic, assign) CGFloat keyboardOffset;
@property (nonatomic, assign) BOOL scrollingExpandsSheet;
@property (nonatomic, assign) facebook::react::TrueSheetViewTopScrollEdgeEffect topScrollEdgeEffect;
@property (nonatomic, assign) facebook::react::TrueSheetViewBottomScrollEdgeEffect bottomScrollEdgeEffect;

/**
 * Derived from `contentInsetAdjustment` — which of the two bottom insets apply
 */
@property (nonatomic, readonly) BOOL safeAreaInsetAdjustment;
@property (nonatomic, readonly) BOOL footerInsetAdjustment;

@end

@class TrueSheetPeekView;

@protocol TrueSheetContainerViewDelegate <NSObject>

- (void)containerViewContentDidChangeSize:(CGSize)newSize;
- (void)containerViewScrollViewDidChange;
- (void)containerViewDidMountTransaction;

@optional

- (void)containerViewHeaderDidChangeSize:(CGSize)newSize;
- (void)containerViewFooterDidChangeSize:(CGSize)newSize;
- (void)containerViewPeekDidChangeSize:(CGSize)newSize;

@end

@interface TrueSheetContainerView : RCTViewComponentView

/**
 * Delegate to notify of content size changes
 */
@property (nonatomic, weak, nullable) id<TrueSheetContainerViewDelegate> delegate;

/**
 * Options for scrollable behavior
 */
@property (nonatomic, strong, nullable) ScrollableOptions *scrollableOptions;

/**
 * React tag of the user-provided scrollable within the content (see the `scrollableRef` prop)
 */
@property (nonatomic, assign) NSInteger scrollableHandle;

/**
 * Whether the resolved scrollable gets the bottom safe-area inset (UIKit's
 * `contentInsetAdjustmentBehavior` set to `automatic`) — already gated by the
 * sheet's `insetAdjustment`
 */
@property (nonatomic, assign) BOOL safeAreaInsetAdjustment;

/**
 * Whether the resolved scrollable is padded by the absolute footer's height —
 * already gated by the footer position and a plugged scrollable
 */
@property (nonatomic, assign) BOOL footerInsetAdjustment;

/**
 * Bottom safe-area inset the footer absorbs as padding — the footer
 * owns the sheet's bottom edge, so its background fills the inset
 */
@property (nonatomic, assign) CGFloat footerBottomInset;

/**
 * Returns the current content height
 */
- (CGFloat)contentHeight;

/**
 * Returns the current header height
 */
- (CGFloat)headerHeight;

/**
 * Returns the current footer height
 */
- (CGFloat)footerHeight;

/**
 * Returns the bottom inset currently baked into the footer's height
 */
- (CGFloat)footerAppliedBottomInset;

/**
 * Returns the current height of the peek view within the content
 */
- (CGFloat)peekContentHeight;

/**
 * Registers a peek view found within the content subtree
 */
- (void)attachPeekView:(TrueSheetPeekView *)peekView;

/**
 * Re-applies the footer's keyboard slide to reflect a live `keyboardOffset` change.
 */
- (void)updateFooterKeyboardOffset;

- (BOOL)hasAccessibilityFooterElements;

/**
 * Setup scrollable content
 */
- (void)setupScrollable;

/**
 * Setup keyboard observer for content and footer
 * @param viewController The sheet view controller to observe keyboard events for
 */
- (void)setupKeyboardObserverWithViewController:(UIViewController *)viewController;

/**
 * Cleanup keyboard observer
 */
- (void)cleanupKeyboardObserver;

@end

NS_ASSUME_NONNULL_END

#endif

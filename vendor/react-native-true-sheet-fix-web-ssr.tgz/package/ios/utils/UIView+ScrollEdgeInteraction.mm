//
//  Created by Jovanni Lo (@lodev09)
//  Copyright (c) 2024-present. All rights reserved.
//
//  This source code is licensed under the MIT license found in the
//  LICENSE file in the root directory of this source tree.
//

#ifdef RCT_NEW_ARCH_ENABLED

#import <objc/runtime.h>
#import "PlatformUtil.h"
#import "UIView+ScrollEdgeInteraction.h"

static const void *kEdgeEffectHintKey = &kEdgeEffectHintKey;

@implementation UIView (ScrollEdgeInteraction)

- (void)cleanupEdgeInteraction API_AVAILABLE(ios(26.0)) {
#if RNTS_IPHONE_OS_VERSION_AVAILABLE(26_0)
  for (id<UIInteraction> interaction in [self.interactions copy]) {
    if ([interaction isKindOfClass:[UIScrollEdgeElementContainerInteraction class]]) {
      [self removeInteraction:interaction];
      break;
    }
  }
#endif

  UILabel *hint = objc_getAssociatedObject(self, kEdgeEffectHintKey);
  [hint removeFromSuperview];
  objc_setAssociatedObject(self, kEdgeEffectHintKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (nullable UIScrollView *)edgeInteractionScrollView API_AVAILABLE(ios(26.0)) {
#if RNTS_IPHONE_OS_VERSION_AVAILABLE(26_0)
  for (id<UIInteraction> interaction in self.interactions) {
    if ([interaction isKindOfClass:[UIScrollEdgeElementContainerInteraction class]]) {
      return ((UIScrollEdgeElementContainerInteraction *)interaction).scrollView;
    }
  }
#endif
  return nil;
}

- (void)setupEdgeInteractionWithScrollView:(nullable UIScrollView *)scrollView
                                      edge:(UIRectEdge)edge API_AVAILABLE(ios(26.0)) {
  if (!scrollView) {
    [self cleanupEdgeInteraction];
    return;
  }

#if RNTS_IPHONE_OS_VERSION_AVAILABLE(26_0)
  // Update in place — this re-runs on every footer/header size change, and
  // tearing the interaction down mid keyboard animation flashes the edge
  // effect at the footer's final position.
  for (id<UIInteraction> interaction in self.interactions) {
    if ([interaction isKindOfClass:[UIScrollEdgeElementContainerInteraction class]]) {
      UIScrollEdgeElementContainerInteraction *existing = (UIScrollEdgeElementContainerInteraction *)interaction;
      existing.scrollView = scrollView;
      existing.edge = edge;
      return;
    }
  }

  // UIScrollEdgeElementContainerInteraction requires standard UIKit element
  // descendants (UILabel, UIControl, etc.) to trigger the edge effect.
  // RCTViewComponentView subviews are not recognized, so we add a
  // non-visible UILabel as an element hint.
  UILabel *hint = [[UILabel alloc] initWithFrame:self.bounds];
  hint.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  hint.userInteractionEnabled = NO;
  [self addSubview:hint];
  objc_setAssociatedObject(self, kEdgeEffectHintKey, hint, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

  UIScrollEdgeElementContainerInteraction *interaction = [[UIScrollEdgeElementContainerInteraction alloc] init];
  interaction.scrollView = scrollView;
  interaction.edge = edge;
  [self addInteraction:interaction];
#endif
}

@end

#endif

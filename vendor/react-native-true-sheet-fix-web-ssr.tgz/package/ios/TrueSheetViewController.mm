//
//  Created by Jovanni Lo (@lodev09)
//  Copyright (c) 2024-present. All rights reserved.
//
//  This source code is licensed under the MIT license found in the
//  LICENSE file in the root directory of this source tree.
//

#import "TrueSheetViewController.h"
#import "TrueSheetContainerView.h"
#import "TrueSheetContentView.h"
#import "TrueSheetOverlayView.h"
#import "core/TrueSheetBlurView.h"
#import "core/TrueSheetDetentCalculator.h"
#import "core/TrueSheetDimView.h"
#import "core/TrueSheetGrabberView.h"
#import "utils/BlurUtil.h"
#import "utils/GestureUtil.h"
#import "utils/PlatformUtil.h"
#import "utils/UIView+FirstResponder.h"
#import "utils/WindowUtil.h"

#import <React/RCTLog.h>
#import <React/RCTScrollViewComponentView.h>
#import <objc/runtime.h>
#import <react/renderer/components/TrueSheetSpec/Props.h>

using namespace facebook::react;

typedef struct {
  CGFloat position;
  CGFloat detent;
  CGFloat index;
} TrueSheetPositionState;

static BOOL TrueSheetPositionStateEquals(TrueSheetPositionState a, TrueSheetPositionState b) {
  return fabs(a.position - b.position) <= 0.01 && fabs(a.detent - b.detent) <= 0.01 && fabs(a.index - b.index) <= 0.01;
}

static char TrueSheetAccessibilityWindowOwnerKey;
static char TrueSheetAccessibilityWindowPreviousElementsKey;

@interface TrueSheetViewController ()

- (UIViewController *)accessibilityPresentingViewController;
- (void)setupTransitionTracker;
- (void)settleAtDetentIndex:(NSInteger)index debug:(NSString *)debug;
- (void)restoreWindowAccessibilityElements;
- (void)setSheetAccessibilityElementsHidden:(BOOL)hidden;
- (void)setAccessibilityContentElement:(UIView *)contentView;
- (NSArray *)accessibilityGrabberElements;
- (void)endInteractiveDismissState;
- (void)updateHingeState;
- (void)correctHingeOffsetForIndex:(NSInteger)index;
- (CGFloat)tabletopHingeEdge;
- (CGFloat)hingeOffsetForHeight:(CGFloat)height;
- (void)animateInteractiveContainerToTransform:(CGAffineTransform)transform
                                      duration:(NSTimeInterval)duration
                          allowUserInteraction:(BOOL)allowUserInteraction
                                    completion:(void (^)(void))completion;

@end

// VoiceOver delivers the two-finger Z (escape) gesture by walking up the view
// hierarchy from the focused element, so the sheet's root view handles it.
@interface TrueSheetControllerView : UIView
@property (nonatomic, weak) TrueSheetViewController *controller;
@end

@implementation TrueSheetControllerView

- (BOOL)accessibilityPerformEscape {
  return [self.controller accessibilityPerformEscape];
}

@end

@implementation TrueSheetViewController {
  TrueSheetPositionState _lastEmittedPositionState;
  CGSize _lastReportedSize;
  // Net of the footer's baked-in inset, snapshotted together: the inset updates
  // with the footer's layout, but a size change mid-present is deferred to
  // didPresent, so subtracting it live pairs a new inset with a stale height.
  CGFloat _autoDetentHeight;
  CGFloat _peekDetentHeight;
  NSInteger _pendingDetentIndex;
  NSInteger _displayedBackgroundIndex;
  BOOL _usesBackgroundEffects;
  BOOL _refusedPanDismiss;

  // Present/dismiss tracking: a display link scoped to the transition
  // coordinator — started alongside the transition, stopped in its completion.
  CADisplayLink *_transitionLink;
  BOOL _isTransitioning;
  // Where the sheet rests during the transition: the target on present, the start on dismiss
  CGFloat _transitionRestPosition;

  BOOL _pendingContentSizeChange;
  BOOL _pendingDetentsChange;
  BOOL _isDragging;
  BOOL _isWillDismissEmitted;

  // Last bottom safe area observed while presented — reused as the estimate
  // for the next present (beats the float-threshold guess for re-presents).
  BOOL _hasObservedBottomInset;
  CGFloat _observedBottomInset;
  BOOL _isRefreshingSafeArea;

  BOOL _isInteractiveDismiss;
  CGFloat _interactiveStartPosition;
  UIView *_interactiveContainerView;
  NSUInteger _interactiveGeneration;
  CADisplayLink *_interactivePositionLink;

  __weak TrueSheetViewController *_parentSheetController;
  __weak UIView *_presenterFirstResponder;

  UIView *_anchorView;

  __weak UIWindow *_accessibilityWindow;
  BOOL _appliedAccessibilityFooterElements;

  TrueSheetBlurView *_blurView;
  TrueSheetGrabberView *_grabberView;
  TrueSheetDetentCalculator *_detentCalculator;
  TrueSheetDimView *_dimView;

  // Foldable hinge (iOS 27.1+). Tabletop resolves on demand from the window's
  // division region; these track the last applied posture to detect changes.
  BOOL _hingeStateKnown;
  CGFloat _hingeEdge;
  NSInteger _hingeRestoreIndex;
  NSInteger _hingeCorrections;
  // Offset learned at the hinge, shared by every hinge-placed detent
  CGFloat _hingeOffset;
  // Offset each hinge-placed detent last resolved with, checked on settle
  NSMutableDictionary<NSNumber *, NSNumber *> *_hingeOffsets;
}

#pragma mark - Initialization

- (instancetype)init {
  if (self = [super initWithNibName:nil bundle:nil]) {
    _detents = @[ @0.5, @1 ];
    _detentBackgrounds = @[];
    _displayedBackgroundIndex = 0;
    _contentHeight = @(0);
    _headerHeight = @(0);
    _footerHeight = @(0);
    _peekContentHeight = @(0);
    _grabber = YES;
    _draggable = YES;
    _scrollingExpandsSheet = YES;
    _footerAvoidsKeyboard = YES;
    _dismissible = YES;
    _dimmed = YES;
    _dimColor = nil;
    _dimOpacity = nil;
    _dimmedDetentIndex = @(0);
    _presentation = facebook::react::TrueSheetViewPresentation::Page;
    _lastEmittedPositionState = (TrueSheetPositionState){0, 0, 0};
    _isDragging = NO;
    _isPresented = NO;
    _isWillDismissEmitted = NO;
    _isTransitioning = NO;
    _pendingContentSizeChange = NO;
    _pendingDetentsChange = NO;
    _activeDetentIndex = -1;
    _pendingDetentIndex = -1;

    _insetAdjustment = TrueSheetViewInsetAdjustment::Automatic;
    _hingeRestoreIndex = -1;
    _hingeOffsets = [NSMutableDictionary dictionary];
    _detentCalculator = [[TrueSheetDetentCalculator alloc] init];
    _detentCalculator.delegate = self;

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(overlayWindowDidChange)
                                                 name:TrueSheetOverlayWindowDidChangeNotification
                                               object:nil];
  }
  return self;
}

- (void)dealloc {
  [self restoreWindowAccessibilityElements];
  [_transitionLink invalidate];
  _transitionLink = nil;
  [_interactivePositionLink invalidate];
  _interactivePositionLink = nil;
  [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Computed Properties

- (UISheetPresentationController *)sheet {
  return self.sheetPresentationController;
}

- (BOOL)isTopmostPresentedController {
  if (!self.isViewLoaded || self.view.window == nil) {
    return NO;
  }
  return self.presentedViewController == nil;
}

// YES while a child controller is stacked on top (e.g. a nested sheet) —
// UIKit's push-back scaling mutates the frame while the sheet is backgrounded.
- (BOOL)isStackedBehindChild {
  UIViewController *presented = self.presentedViewController;
  return presented != nil && !presented.isBeingDismissed;
}

- (UIView *)presentedView {
  return self.sheet.presentedView;
}

- (CGFloat)currentPosition {
  UIView *presentedView = self.presentedView;
  return presentedView ? presentedView.frame.origin.y : 0.0;
}

// YES when any layer from the presented view up to the window has in-flight
// animations (detent snap, present/dismiss transition, container settle).
- (BOOL)isPresentedViewAnimating {
  for (CALayer *layer = self.presentedView.layer; layer; layer = layer.superlayer) {
    if (layer.animationKeys.count > 0) {
      return YES;
    }
  }
  return NO;
}

/**
 * The sheet's live on-screen position. At rest and during drags (direct frame
 * sets) this is the model position; during animations it adds the
 * presentation-vs-model delta measured in window space, so ancestor animations
 * compose and persistent transforms (e.g. floating-sheet inset) cancel out.
 */
- (CGFloat)livePosition {
  UIView *presentedView = self.presentedView;
  UIWindow *window = presentedView.window;
  UIView *containerView = self.sheet.containerView;

  // Direct (non-animated) translation applied during an interactive nav dismiss.
  CGFloat containerTy = containerView ? containerView.transform.ty : 0;

  if (!presentedView || !window || !self.isPresentedViewAnimating) {
    return self.currentPosition + containerTy;
  }

  CALayer *modelLayer = presentedView.layer;
  CALayer *presentationLayer = modelLayer.presentationLayer;
  CALayer *rootModel = window.layer;
  CALayer *rootPresentation = rootModel.presentationLayer;
  if (!presentationLayer || !rootPresentation) {
    return self.currentPosition + containerTy;
  }

  CGFloat modelY = [modelLayer convertPoint:CGPointZero toLayer:rootModel].y;
  CGFloat presentationY = [presentationLayer convertPoint:CGPointZero toLayer:rootPresentation].y;
  return self.currentPosition + (presentationY - modelY) + containerTy;
}

// Some callers run before this controller's view is attached (e.g. mid-presentation
// detent resolution), so fall back to the presenter's window.
- (UIWindow *)hostWindow {
  return self.view.window ?: self.presentingViewController.view.window;
}

- (CGFloat)screenHeight {
  // In a windowed iPad app (Stage Manager, iPadOS 26 windowing) the window can be shorter than
  // UIScreen.mainScreen, so prefer the window's height.
  UIWindow *window = self.hostWindow;
  return window ? window.bounds.size.height : UIScreen.mainScreen.bounds.size.height;
}

// Gap UIKit leaves between a floating sheet (iOS 26+) and the screen's bottom edge
static const CGFloat TrueSheetFloatingSheetInset = 8;

// Largest resolved detent UIKit floats on iOS 26+. A floating sheet gets no
// bottom safe-area inset; anything taller is edge-attached and gets it added.
static const CGFloat TrueSheetFloatingDetentMaxHeight = 100;

// Only phone sheets absorb the bottom safe-area inset — non-phone idioms
// (iPad form sheets) are inset from the screen edge by UIKit.
static BOOL TrueSheetIsPhoneIdiom(void) {
  return UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPhone;
}

- (CGFloat)detentBottomAdjustmentForHeight:(CGFloat)height {
  if (_insetAdjustment == TrueSheetViewInsetAdjustment::Automatic) {
    return 0;
  }

  CGFloat inset = [self bottomSafeAreaForHeight:height];
  if (@available(iOS 26.0, *)) {
    // Subtracting the full inset can resolve the detent small enough to float,
    // which drops the inset and leaves the sheet shorter than its content.
    // Keep it edge-attached instead.
    return fmin(inset, fmax(0, height - TrueSheetFloatingDetentMaxHeight - 1));
  }

  return inset;
}

- (CGFloat)bottomSafeAreaForHeight:(CGFloat)height {
  if (!TrueSheetIsPhoneIdiom()) {
    return 0;
  }

  // Floating sheets (iOS 26+) get no bottom inset
  if (@available(iOS 26.0, *)) {
    if (height <= TrueSheetFloatingDetentMaxHeight) {
      return 0;
    }
  }

  UIWindow *window = [WindowUtil keyWindow];
  return window ? window.safeAreaInsets.bottom : 0;
}

/**
 * Largest height the sheet can reach across its configured detents, excluding
 * the inset currently baked into the footer's height. Basis for the footer's
 * inset absorption so it follows the same rule as bottomSafeAreaForHeight: —
 * a sheet that only ever floats (small detents on iOS 26) keeps its footer
 * unpadded.
 */
- (CGFloat)maxNaturalDetentHeight {
  CGFloat maxHeight = 0;

  for (id detent in self.detents) {
    if (![detent isKindOfClass:[NSNumber class]]) {
      continue;
    }

    CGFloat value = [detent doubleValue];
    CGFloat height = 0;
    if (value == -1) {
      height = [_detentCalculator autoHeightForKeyboardHeight:0] - [self autoDetentBottomInset];
    } else if (value == -2) {
      height = [_detentCalculator peekHeight] - [self peekDetentBottomInset];
    } else if (value > 0 && value <= 1) {
      height = value * self.screenHeight;
    }
    maxHeight = fmax(maxHeight, height);
  }

  if (self.maxContentHeight) {
    maxHeight = fmin(maxHeight, [self.maxContentHeight floatValue]);
  }

  return maxHeight > 0 ? maxHeight : self.screenHeight;
}

// The inset the footer absorbs as padding.
- (CGFloat)footerBottomInset {
  if (_insetAdjustment != TrueSheetViewInsetAdjustment::Automatic) {
    return 0;
  }

  // Early out so the maxNaturalDetentHeight fallback below doesn't run per
  // layout pass on iPad only to be zeroed by bottomSafeAreaForHeight:.
  if (!TrueSheetIsPhoneIdiom()) {
    return 0;
  }

  // Once laid out, the sheet's own safe area is the authority — it reflects
  // UIKit's actual float/anchored decision (a floating sheet gets 0), where
  // bottomSafeAreaForHeight: can only guess the float threshold. Guessing
  // wrong leaves the safe-area region unfilled (gap) or double-padded.
  UIView *view = self.viewIfLoaded;
  if (view.window) {
    // Mid-present, hold the expected inset over a stale zero so the footer
    // doesn't shrink and regrow — viewDidAppear forces the real value.
    if (!_isPresented && [self hasStaleBottomSafeArea]) {
      return [self bottomSafeAreaForHeight:view.bounds.size.height];
    }

    _hasObservedBottomInset = YES;
    _observedBottomInset = view.safeAreaInsets.bottom;
    return _observedBottomInset;
  }

  // Off-window while presented (e.g. hidden behind a native screen): the last
  // observed value is this sheet's own truth — prefer it over the
  // float-threshold guess. Cleared on dismiss so a re-present observes fresh
  // geometry (rotation or detent changes while dismissed would stale it).
  if (_hasObservedBottomInset) {
    return _observedBottomInset;
  }

  return [self bottomSafeAreaForHeight:[self maxNaturalDetentHeight]];
}

// Re-resolve alongside the keyboard animation as its overlap with the pinned
// footer changes, including keyboard height changes while already visible.
- (void)setKeyboardHeight:(CGFloat)keyboardHeight {
  if (_keyboardHeight == keyboardHeight) {
    return;
  }
  _keyboardHeight = keyboardHeight;

  if (_footerInsetAdjustment && !_footerAvoidsKeyboard && self.isPresented) {
    [self setupSheetDetentsForSizeChange];
  }
}

/**
 * Bottom inset excluded from the auto detent. A relative footer (or an
 * absolute one padding the scrollable) owns the sheet's bottom edge and
 * carries the inset in its height (see footerBottomInset) — subtract exactly
 * what was baked in so UIKit's own safe-area layout doesn't double it.
 */
- (CGFloat)autoDetentBottomInset {
  if ((_absoluteFooter && !self.footerInsetAdjustment) || [self.footerHeight floatValue] <= 0) {
    return 0;
  }

  return _appliedFooterBottomInset;
}

/**
 * Bottom inset excluded from the peek detent. An absolute footer counts
 * toward the peek height and carries the inset in its height — subtract
 * exactly what was baked in so it isn't doubled.
 */
- (CGFloat)peekDetentBottomInset {
  if (!_absoluteFooter || [self.footerHeight floatValue] <= 0) {
    return 0;
  }

  return _appliedFooterBottomInset;
}

- (BOOL)isDesignCompatibilityMode {
  if (@available(iOS 27.0, *)) {
    return NO;
  }
  if (@available(iOS 26.0, *)) {
    NSNumber *value = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"UIDesignRequiresCompatibility"];
    return value.boolValue;
  }
  return NO;
}

- (NSInteger)currentDetentIndex {
  UISheetPresentationController *sheet = self.sheet;
  if (!sheet)
    return -1;

  UISheetPresentationControllerDetentIdentifier selectedIdentifier = sheet.selectedDetentIdentifier;
  if (!selectedIdentifier)
    return -1;

  NSArray<UISheetPresentationControllerDetent *> *detents = sheet.detents;
  for (NSInteger i = 0; i < detents.count; i++) {
    if (@available(iOS 16.0, *)) {
      if ([detents[i].identifier isEqualToString:selectedIdentifier]) {
        return i;
      }
    } else {
      if ([selectedIdentifier isEqualToString:UISheetPresentationControllerDetentIdentifierMedium]) {
        return 0;
      } else if ([selectedIdentifier isEqualToString:UISheetPresentationControllerDetentIdentifierLarge]) {
        return detents.count - 1;
      }
    }
  }

  return -1;
}

#pragma mark - View Lifecycle

- (void)loadView {
  TrueSheetControllerView *view = [[TrueSheetControllerView alloc] init];
  view.controller = self;
  self.view = view;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;

  _blurView = [[TrueSheetBlurView alloc] init];
  [_blurView addToView:self.view];

  _grabberView = [[TrueSheetGrabberView alloc] init];
  _grabberView.hidden = YES;
  [_grabberView addToView:self.view];

#if RNTS_IPHONE_OS_VERSION_AVAILABLE(27_1)
  if (@available(iOS 27.1, *)) {
    __weak __typeof(self) weakSelf = self;
    UIHingeInteraction *hingeInteraction =
      [[UIHingeInteraction alloc] initWithUpdateHandler:^(UIHingeInteraction *_, UIHingeInteractionUpdate *__) {
        // Next run loop, so the division region reflects the new posture
        dispatch_async(dispatch_get_main_queue(), ^{
          [weakSelf updateHingeState];
        });
      }];
    [self.view addInteraction:hingeInteraction];
  }
#endif
}

#pragma mark - Custom Dimming

// UISheetPresentationController has no API for the dim's color or opacity, so a custom
// color/opacity turns the native dim off and fades in our own view behind the sheet.
- (BOOL)useCustomDimming {
  return self.dimmed && (self.dimColor != nil || self.dimOpacity != nil);
}

- (BOOL)isDimmedAtEveryDetent {
  return self.dimmed && [self.dimmedDetentIndex integerValue] == 0;
}

// Like the system dim, fades in between the detent below `dimmedDetentIndex` and the dimmed detent.
- (CGFloat)dimAlphaForIndex:(CGFloat)index {
  if (![self useCustomDimming]) {
    return 0;
  }

  CGFloat progress = index - [self.dimmedDetentIndex integerValue] + 1;
  return fmax(0, fmin(1, progress));
}

// Present and dismiss fade the dim over the whole travel below the resting position.
- (CGFloat)dimAlphaForPosition:(CGFloat)position index:(CGFloat)index {
  if (!_isTransitioning || position <= _transitionRestPosition) {
    return [self dimAlphaForIndex:index];
  }

  CGFloat travel = self.screenHeight - _transitionRestPosition;
  CGFloat progress = travel > 0 ? fmax(0, (self.screenHeight - position) / travel) : 0;
  return [self dimAlphaForIndex:[self interpolatedIndexForPosition:_transitionRestPosition]] * progress;
}

- (void)setupDimView {
  UIView *container = self.presentationController.containerView;
  if (!container || (!_dimView && ![self useCustomDimming])) {
    return;
  }

  if (!_dimView) {
    _dimView = [[TrueSheetDimView alloc] init];

    __weak __typeof(self) weakSelf = self;
    _dimView.onTap = ^{
      [weakSelf handleDimViewTap];
    };
  }

  // Keep opacity in the color so a transparent dim still receives touches.
  UIColor *color = self.dimColor ?: [UIColor blackColor];
  CGFloat opacity = self.dimOpacity ? [self.dimOpacity doubleValue] : 0.5;
  _dimView.backgroundColor = [color colorWithAlphaComponent:CGColorGetAlpha(color.CGColor) * opacity];
  [_dimView addToView:container];
}

- (void)handleDimViewTap {
  if (self.dismissible) {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
  }
}

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:animated];

  _blurView.alpha = 1;

  if (!_isPresented) {
    UIViewController *presenter = self.presentingViewController;
    if ([presenter isKindOfClass:[TrueSheetViewController class]]) {
      _parentSheetController = (TrueSheetViewController *)presenter;
      [_parentSheetController.delegate viewControllerWillBlur];
      [_parentSheetController setAccessibilityContentElement:self.accessibilityContentView ?: self.view];
    }

    [self setupDimView];

    // A new presentation records the posture it starts in
    _hingeStateKnown = NO;
    _hingeRestoreIndex = -1;
    _hingeOffset = 0;

    // UIKit hides the presenter's keyboard under a sheet dimmed at every detent and
    // brings it back on dismiss, but custom dimming leaves the native sheet undimmed.
    if ([self useCustomDimming] && [self isDimmedAtEveryDetent]) {
      UIView *firstResponder = [presenter.view findFirstResponder];
      if ([firstResponder resignFirstResponder]) {
        _presenterFirstResponder = firstResponder;
      }
    }

    dispatch_async(dispatch_get_main_queue(), ^{
      NSInteger index = self.currentDetentIndex;
      CGFloat position = self.currentPosition;
      CGFloat detent = [self detentValueForIndex:index];

      [self.delegate viewControllerWillPresentAtIndex:index position:position detent:detent];
      [self.delegate viewControllerWillFocus];
    });
  }

  [self setupTransitionTracker];
}

- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];
  [self setSheetAccessibilityElementsHidden:NO];

  if (!_isPresented) {
    [_parentSheetController.delegate viewControllerDidBlur];

    dispatch_async(dispatch_get_main_queue(), ^{
      NSInteger index = [self currentDetentIndex];
      CGFloat detent = [self detentValueForIndex:index];
      [self.delegate viewControllerDidPresentAtIndex:index position:self.currentPosition detent:detent];
      [self.delegate viewControllerDidFocus];

      [self->_grabberView updateAccessibilityValueWithIndex:index detentCount:self->_detents.count];
      [self settleAtDetentIndex:index debug:@"did present"];

      // Apply a posture change that happened while presenting
      [self updateHingeState];
    });

    [self setupGestureRecognizer];
    _isPresented = YES;
    [self refreshStaleBottomSafeArea];
  }

  [self setupAccessibilityContainer];
}

/**
 * A present that overlaps another transition (e.g. re-presenting while a
 * native stack pops) can leave the root view's bottom safe area at zero, and
 * UIKit doesn't recompute it until the sheet's frame next changes. Suspect a
 * zero the presented height says shouldn't be there — a small floating sheet
 * legitimately has none.
 */
- (BOOL)hasStaleBottomSafeArea {
  UIView *view = self.viewIfLoaded;
  return view.window && view.safeAreaInsets.bottom <= 0 && [self bottomSafeAreaForHeight:view.bounds.size.height] > 0;
}

// Toggling additionalSafeAreaInsets forces UIKit to recompute the safe area.
// The toggle's intermediate value isn't reported, so the footer only sees the
// settled one.
- (void)refreshStaleBottomSafeArea {
  if (![self hasStaleBottomSafeArea]) {
    return;
  }

  _isRefreshingSafeArea = YES;
  UIEdgeInsets insets = self.additionalSafeAreaInsets;
  self.additionalSafeAreaInsets = UIEdgeInsetsMake(insets.top, insets.left, insets.bottom + 1, insets.right);
  self.additionalSafeAreaInsets = insets;
  _isRefreshingSafeArea = NO;

  [self.delegate viewControllerSafeAreaInsetsDidChange];
}

- (void)setupAccessibilityContainer {
  UIView *contentView = self.accessibilityContentView;
  if (!contentView) {
    return;
  }

  [self setAccessibilityContentElement:contentView];
}

// Only the topmost sheet may refresh, or it would steal the window
// accessibility override from the child presented over it.
- (BOOL)canRefreshAccessibilityContainer {
  return _isPresented && !self.isBeingDismissed && self.isTopmostPresentedController;
}

- (void)refreshAccessibilityContainer {
  if (self.canRefreshAccessibilityContainer) {
    [self setupAccessibilityContainer];
  }
}

- (void)refreshAccessibilityContainerIfFooterChanged {
  // Only a dimmed sheet's boundary depends on the footer
  if (!_dimmed || !self.canRefreshAccessibilityContainer) {
    return;
  }

  UIView *contentView = self.accessibilityContentView;
  if (![contentView isKindOfClass:[TrueSheetContainerView class]] ||
      [(TrueSheetContainerView *)contentView hasAccessibilityFooterElements] == _appliedAccessibilityFooterElements) {
    return;
  }

  [self setAccessibilityContentElement:contentView];
  UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, nil);
}

- (void)overlayWindowDidChange {
  if (!self.canRefreshAccessibilityContainer) {
    return;
  }

  [self setupAccessibilityContainer];
  UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, nil);
}

- (UIViewController *)accessibilityPresentingViewController {
  UIViewController *presentingViewController = self.presentingViewController;
  while ([presentingViewController isKindOfClass:[TrueSheetViewController class]] &&
         presentingViewController.presentingViewController) {
    presentingViewController = presentingViewController.presentingViewController;
  }
  return presentingViewController;
}

- (void)restoreWindowAccessibilityElements {
  UIWindow *window = _accessibilityWindow;
  if (window) {
    // The active sheet may temporarily own window accessibility traversal. Only
    // restore the previous value when this controller still owns that override.
    NSValue *ownerValue = objc_getAssociatedObject(window, &TrueSheetAccessibilityWindowOwnerKey);
    if (ownerValue && ownerValue.nonretainedObjectValue == self) {
      id previousElements = objc_getAssociatedObject(window, &TrueSheetAccessibilityWindowPreviousElementsKey);
      window.accessibilityElements = previousElements == [NSNull null] ? nil : previousElements;
      objc_setAssociatedObject(window, &TrueSheetAccessibilityWindowOwnerKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
      objc_setAssociatedObject(
        window, &TrueSheetAccessibilityWindowPreviousElementsKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }

    _accessibilityWindow = nil;
  }
}

- (void)setSheetAccessibilityElementsHidden:(BOOL)hidden {
  self.view.accessibilityElementsHidden = hidden;

  UIView *presentedView = self.presentationController.presentedView;
  if (presentedView) {
    presentedView.accessibilityElementsHidden = hidden;
  }
}

- (NSArray *)accessibilityGrabberElements {
  if (_grabberView && !_grabberView.hidden) {
    return @[ _grabberView ];
  }

  // The system grabber is an accessibility element UIKit adds to the presented view
  // (a sibling of our root view). Expose it so VoiceOver can resize or dismiss with it.
  // UIKit also keeps a transparent bottom grabber there, so skip invisible views.
  NSMutableArray *elements = [NSMutableArray array];
  for (UIView *subview in self.presentationController.presentedView.subviews) {
    if (subview != self.view && subview.isAccessibilityElement && !subview.hidden && subview.alpha > 0) {
      [elements addObject:subview];
    }
  }
  return elements;
}

- (BOOL)accessibilityPerformEscape {
  if (!_isPresented) {
    return NO;
  }

  if (!self.dismissible) {
    [self.delegate viewControllerDidAttemptDismiss];
    return NO;
  }

  [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
  return YES;
}

- (void)setAccessibilityContentElement:(UIView *)contentView {
  BOOL hasAccessibilityFooterElements = [contentView isKindOfClass:[TrueSheetContainerView class]] &&
                                        [(TrueSheetContainerView *)contentView hasAccessibilityFooterElements];
  // Footer controls exposed as separate accessibility elements can be skipped
  // by XCTest when the presented sheet is a hard modal accessibility boundary.
  BOOL isAccessibilityModal = _dimmed && !hasAccessibilityFooterElements;
  _appliedAccessibilityFooterElements = hasAccessibilityFooterElements;

  // At a hard modal boundary XCTest skips nested elements, so flatten the
  // container's children into the array. Otherwise expose the container itself:
  // its accessibilityElements getter recomputes live, so a footer/content subtree
  // that remounts (e.g. swapping a footer button on a state change) stays
  // discoverable instead of leaving this snapshot pointing at destroyed views.
  NSMutableArray *accessibilityElements = [[self accessibilityGrabberElements] mutableCopy];
  if (isAccessibilityModal) {
    NSArray *contentElements = contentView.accessibilityElements;
    [accessibilityElements addObjectsFromArray:contentElements.count > 0 ? contentElements : @[ contentView ]];
  } else {
    [accessibilityElements addObject:contentView];
  }

  self.view.isAccessibilityElement = NO;
  self.view.accessibilityViewIsModal = YES;
  self.view.accessibilityElements = accessibilityElements;

  UIView *presentedView = self.presentationController.presentedView;
  if (presentedView) {
    presentedView.isAccessibilityElement = NO;
    presentedView.accessibilityViewIsModal = isAccessibilityModal;
    presentedView.accessibilityElements = accessibilityElements;

    // The system grabber is a sibling of our root view, so an escape performed while it
    // is focused walks presentedView → window and never reaches TrueSheetControllerView.
    if (@available(iOS 17.0, *)) {
      __weak __typeof(self) weakSelf = self;
      presentedView.accessibilityPerformEscapeBlock = ^BOOL {
        return [weakSelf accessibilityPerformEscape];
      };
    }

    UIWindow *window = self.view.window;
    UIViewController *presentingViewController = [self accessibilityPresentingViewController];
    if (window && presentingViewController.view) {
      if (!_accessibilityWindow) {
        _accessibilityWindow = window;
        id previousElements = objc_getAssociatedObject(window, &TrueSheetAccessibilityWindowPreviousElementsKey);
        if (!previousElements) {
          previousElements = window.accessibilityElements ?: [NSNull null];
          objc_setAssociatedObject(window, &TrueSheetAccessibilityWindowPreviousElementsKey, previousElements,
            OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
      }
      objc_setAssociatedObject(window, &TrueSheetAccessibilityWindowOwnerKey, [NSValue valueWithNonretainedObject:self],
        OBJC_ASSOCIATION_RETAIN_NONATOMIC);
      NSArray *sheetElements =
        isAccessibilityModal ? @[ presentedView ] : @[ presentingViewController.view, presentedView ];
      // Overlays render above every sheet. Listed first, since accessibility
      // hit testing takes the first element containing the point.
      window.accessibilityElements =
        [[TrueSheetOverlayView overlayContainersInWindow:window] arrayByAddingObjectsFromArray:sheetElements];
      return;
    }
  }

  [self restoreWindowAccessibilityElements];
}

#pragma mark - Presentation

- (void)presentViewController:(UIViewController *)viewControllerToPresent
                     animated:(BOOL)flag
                   completion:(void (^)(void))completion {
  // A non-sheet controller (e.g. an action sheet, alert, or image picker) is about
  // to present over us. Clear our window accessibility override so UIKit's default
  // traversal surfaces it for XCTest and assistive technologies; we reclaim the
  // override when it dismisses. Nested sheets claim their own override.
  if (![viewControllerToPresent isKindOfClass:[TrueSheetViewController class]]) {
    self.view.window.accessibilityElements = nil;
  }

  [super presentViewController:viewControllerToPresent animated:flag completion:completion];
}

- (void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion {
  [super dismissViewControllerAnimated:flag
                            completion:^{
                              if (completion) {
                                completion();
                              }

                              // Reclaim the window accessibility override once nothing
                              // else is presented over us.
                              if (self.isPresented && self.presentedViewController == nil) {
                                [self setupAccessibilityContainer];
                              }
                            }];
}

- (void)emitWillDismissEvents {
  if (self.isBeingDismissed && !_isWillDismissEmitted) {
    _isWillDismissEmitted = YES;

    [self.delegate viewControllerWillBlur];
    [self.delegate viewControllerWillDismiss];
    [_parentSheetController.delegate viewControllerWillFocus];

    // Restored once the dismiss commits, like UIKit's own keyboard preservation.
    UIView *firstResponder = _presenterFirstResponder;
    _presenterFirstResponder = nil;
    if (!self.presentingViewController.isBeingDismissed) {
      [firstResponder becomeFirstResponder];
    }
  }
}

- (void)emitDidDismissEvents {
  if (self.isBeingDismissed) {
    [self restoreWindowAccessibilityElements];
    _isPresented = NO;
    _isWillDismissEmitted = NO;
    _hasObservedBottomInset = NO;

    [_dimView removeFromSuperview];
    _dimView = nil;

    [_anchorView removeFromSuperview];
    _anchorView = nil;

    [_parentSheetController.delegate viewControllerDidFocus];
    [_parentSheetController setSheetAccessibilityElementsHidden:NO];
    [_parentSheetController setupAccessibilityContainer];
    _parentSheetController = nil;

    [self.delegate viewControllerDidBlur];
    [self.delegate viewControllerDidDismiss];
  }
}

- (void)viewWillDisappear:(BOOL)animated {
  [super viewWillDisappear:animated];
  [self restoreWindowAccessibilityElements];
  [self setSheetAccessibilityElementsHidden:YES];

  // Dismissing with a child on top only animates the child out — this sheet
  // doesn't move and isn't part of that transition, so fade its dim over it.
  if (self.isBeingDismissed && self.presentedViewController) {
    [UIView animateWithDuration:self.transitionCoordinator.transitionDuration
                     animations:^{
                       self->_dimView.alpha = 0;
                     }];
  }

  // A swipe can still be cancelled, so emit once it commits on release. Any
  // other dismiss (programmatic, outside tap, navigation) is already committed.
  id<UIViewControllerTransitionCoordinator> coordinator = self.transitionCoordinator;
  if (coordinator.isInteractive) {
    __weak __typeof(self) weakSelf = self;
    [coordinator
      notifyWhenInteractionChangesUsingBlock:^(id<UIViewControllerTransitionCoordinatorContext> _Nonnull context) {
        if (!context.isCancelled) {
          [weakSelf emitWillDismissEvents];
        }
      }];
  } else {
    [self emitWillDismissEvents];
  }

  [self setupTransitionTracker];
}

- (void)viewDidDisappear:(BOOL)animated {
  [super viewDidDisappear:animated];

  // Backstop: if the sheet is torn down mid-gesture (e.g. owning view deallocated),
  // the observer can't reach us through its weak delegate, so end here to invalidate
  // _interactivePositionLink — which otherwise retains this controller indefinitely.
  if (_isInteractiveDismiss) {
    [self endInteractiveDismissState];
  }

  // Dismissing with the keyboard up skips the hide notification — don't let
  // the stale flag block learning on the next present, or a stale height keep
  // the footer out of the auto detent.
  _keyboardSheetGrown = NO;
  _keyboardHeight = 0;
  _minimizedKeyboardOverlap = 0;

  [self emitDidDismissEvents];
}

- (void)viewWillLayoutSubviews {
  [super viewWillLayoutSubviews];

  // Skip during transitions and nav swipes — their trackers own position then.
  if (_isTransitioning || _isInteractiveDismiss) {
    return;
  }

  // Mid-drag the frame tracks the finger — never settle or learn from it;
  // pending changes keep their flags and settle on the first post-drag layout.
  if ((_pendingContentSizeChange || _pendingDetentsChange) && !_isDragging) {
    _pendingContentSizeChange = NO;
    _pendingDetentsChange = NO;
    [self settleAtDetentIndex:self.currentDetentIndex debug:@"layout"];
  } else {
    // A child on top moves this sheet two ways: an animated collapse/restore
    // step (presenting/dismissing) — emit the target non-realtime so JS
    // animates to it — or direct per-frame re-layouts while the child drags,
    // which stay realtime. Mid-drag no child is on top, so drags emit realtime.
    BOOL realtime = self.presentedViewController == nil || !self.isPresentedViewAnimating;

    // A layout pass at rest can nudge the frame by a sub-pixel amount
    // (pixel-grid snapping after present), leaving the interpolated index
    // slightly off the whole number. Re-learn when the frame is effectively
    // at the current detent so the drift is absorbed instead of emitted.
    // The tight threshold keeps real movement (e.g. scroll-driven expansion
    // or a drag hovering near the detent) from being absorbed.
    if (!_isDragging && self.presentedViewController == nil && !self.isPresentedViewAnimating) {
      NSInteger index = self.currentDetentIndex;
      CGFloat expectedHeight = [_detentCalculator resolvedHeightForIndex:index];
      CGFloat actualHeight = self.screenHeight - self.currentPosition;
      if (expectedHeight > 0 && fabs(actualHeight - expectedHeight) < 2) {
        [self learnOffsetForDetentIndex:index];
      }
    }

    [self emitChangePositionDelegateWithPosition:self.currentPosition realtime:realtime debug:@"layout"];
  }
}

// Rotation or an iPad window resize changes the height fractional detents
// resolve against — re-resolve alongside the transition so the sheet lands on
// the new height instead of waiting for a content-driven rebuild.
- (void)viewWillTransitionToSize:(CGSize)size
       withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
  [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];

  if (@available(iOS 16.0, *)) {
    [coordinator
      animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context) {
        [self.sheet invalidateDetents];
      }
      completion:^(id<UIViewControllerTransitionCoordinatorContext> context) {
        // Rotating a half-open foldable swaps between book and tabletop
        [self updateHingeState];
      }];
  }
}

// Fires when UIKit resolves the sheet's float/anchored placement (present,
// detent resize crossing the float threshold, rotation). The footer's
// absorbed inset follows the observed safe area — repush it right away so
// the footer pads/unpads in the same layout pass.
- (void)viewSafeAreaInsetsDidChange {
  [super viewSafeAreaInsetsDidChange];

  // Mid-dismiss the frame moves off-screen and reports transient insets —
  // don't let them pollute the observed value (matches viewDidLayoutSubviews).
  if (!self.isBeingDismissed && !_isRefreshingSafeArea) {
    [self.delegate viewControllerSafeAreaInsetsDidChange];
  }
}

- (void)viewDidLayoutSubviews {
  [super viewDidLayoutSubviews];

  // viewSafeAreaInsetsDidChange doesn't fire on re-present when the observed
  // inset matches the previous presentation's — refresh every layout pass
  // instead (deduped downstream, so unchanged values are free).
  if (!self.isBeingDismissed) {
    [self.delegate viewControllerSafeAreaInsetsDidChange];
  }

  // Skip size reports while backgrounded behind a stacked child — the push-back
  // scaling changes the frame and would needlessly resize content.
  // _lastReportedSize stays stale so the restore pass re-reports any real change.
  if (!self.isStackedBehindChild) {
    // Report any size change (detent resize, keyboard, rotation) so Yoga
    // relayouts the container synchronously with the sheet.
    CGSize size = self.view.frame.size;
    if (!CGSizeEqualToSize(_lastReportedSize, size)) {
      _lastReportedSize = size;
      [self.delegate viewControllerDidChangeSize:size];
    }
  }

  // The hinge callback can run before the division region updates; the
  // relayout UIKit does for the posture change always sees the new region.
  [self updateHingeState];

  if (_pendingDetentIndex >= 0) {
    NSInteger pendingIndex = _pendingDetentIndex;
    _pendingDetentIndex = -1;

    // The presentedView frame isn't final until UIKit finishes the resize
    // animation — no completion hook exists for it, hence the delay.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
      CGFloat detent = [self detentValueForIndex:pendingIndex];
      [self.delegate viewControllerDidChangeDetent:pendingIndex position:self.currentPosition detent:detent];
      [self->_grabberView updateAccessibilityValueWithIndex:pendingIndex detentCount:self->_detents.count];
      [self settleAtDetentIndex:pendingIndex debug:@"pending detent change"];
    });
  }
}

#pragma mark - Position & Gesture Handling

- (TrueSheetContentView *)findContentView:(UIView *)view {
  if ([view isKindOfClass:[TrueSheetContentView class]]) {
    return (TrueSheetContentView *)view;
  }

  for (UIView *subview in view.subviews) {
    TrueSheetContentView *found = [self findContentView:subview];
    if (found) {
      return found;
    }
  }

  return nil;
}

- (void)setupGestureRecognizer {
  UIView *presentedView = self.presentedView;
  if (!presentedView)
    return;

  if (!self.draggable) {
    [GestureUtil setPanGesturesEnabled:NO forView:presentedView];
    return;
  }

  [GestureUtil attachPanGestureHandler:presentedView target:self selector:@selector(handlePanGesture:)];

  TrueSheetContentView *contentView = [self findContentView:presentedView];
  if (contentView) {
    RCTScrollViewComponentView *scrollViewComponent = [contentView findScrollView];
    if (scrollViewComponent && scrollViewComponent.scrollView) {
      [GestureUtil attachPanGestureHandler:scrollViewComponent.scrollView
                                    target:self
                                  selector:@selector(handlePanGesture:)];
    }
  }
}

- (void)setupDraggable {
  UIView *presentedView = self.presentedView;
  if (!presentedView)
    return;

  [GestureUtil setPanGesturesEnabled:self.draggable forView:presentedView];
}

- (void)handlePanGesture:(UIPanGestureRecognizer *)gesture {
  NSInteger index = self.currentDetentIndex;
  CGFloat detent = [self detentValueForIndex:index];

  [self.delegate viewControllerDidDrag:gesture.state index:index position:self.currentPosition detent:detent];

  switch (gesture.state) {
    case UIGestureRecognizerStateBegan:
      _isDragging = YES;
      break;
    case UIGestureRecognizerStateChanged:
      // Layout owns the emit while the sheet resizes with the finger (a
      // layout pass is already queued), and the transition tick owns it
      // during an interactive dismiss. Translation-only movement (e.g.
      // dragging down to the first detent) triggers neither — emit here as
      // the backup.
      if (!_isTransitioning && !self.presentedView.layer.needsLayout && !self.viewIfLoaded.layer.needsLayout) {
        [self emitChangePositionDelegateWithPosition:self.currentPosition realtime:YES debug:@"drag change"];
      }
      break;
    case UIGestureRecognizerStateEnded:
    case UIGestureRecognizerStateCancelled: {
      if (!_isTransitioning) {
        // Dispatch so UIKit picks the target detent first; the settle emit is
        // non-realtime and JS animates alongside UIKit's snap spring.
        dispatch_async(dispatch_get_main_queue(), ^{
          NSInteger endIndex = self.currentDetentIndex;
          [self->_grabberView updateAccessibilityValueWithIndex:endIndex detentCount:self->_detents.count];
          [self settleAtDetentIndex:endIndex debug:@"drag end"];
        });
      }

      _isDragging = NO;
      break;
    }
    default:
      break;
  }
}

#pragma mark - Position Tracking

/**
 * Tracks the sheet's live position through a present/dismiss transition. The
 * link's lifetime is scoped to the transition coordinator: started alongside
 * the transition, stopped in its completion — which fires for finished and
 * cancelled (interactive) transitions alike.
 */
- (void)setupTransitionTracker {
  id<UIViewControllerTransitionCoordinator> coordinator = self.transitionCoordinator;

  // A cancelled dismiss re-enters viewWillAppear with the same coordinator —
  // the tracker from viewWillDisappear still owns it.
  if (!coordinator || _isTransitioning) {
    return;
  }

  _isTransitioning = YES;
  _transitionRestPosition = self.isBeingDismissed ? self.livePosition : self.currentPosition;

  // Learn the resolver-vs-actual offset before emitting transition positions so
  // the interpolated index lands exactly on the target detent. The presented
  // frame is already final here (UIKit animates the layer, not the frame).
  if (!self.isBeingDismissed) {
    [self learnOffsetForDetentIndex:self.currentDetentIndex];
  }

  __weak __typeof(self) weakSelf = self;
  [coordinator
    animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> _Nonnull context) {
      __strong __typeof(weakSelf) strongSelf = weakSelf;
      if (!strongSelf)
        return;

      [strongSelf->_transitionLink invalidate];
      strongSelf->_transitionLink = [CADisplayLink displayLinkWithTarget:strongSelf
                                                                selector:@selector(handleTransitionTick)];
      // Track at the display's native refresh rate — the default caps at 60Hz
      // on ProMotion, dropping every other frame of a 120Hz animation.
      strongSelf->_transitionLink.preferredFrameRateRange = CAFrameRateRangeMake(60, 120, 120);
      [strongSelf->_transitionLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    }
    completion:^(id<UIViewControllerTransitionCoordinatorContext> _Nonnull context) {
      __strong __typeof(weakSelf) strongSelf = weakSelf;
      if (!strongSelf)
        return;

      [strongSelf->_transitionLink invalidate];
      strongSelf->_transitionLink = nil;
      strongSelf->_isTransitioning = NO;

      // Settle after a present, cancelled dismiss, or detent-snap transition.
      // Delayed because the presentedView frame isn't final until UIKit
      // completes its layout pass after the transition animation — learning
      // here absorbs any sub-pixel drift since the earlier learns. A dismiss
      // cancelled mid-drag leaves the finger down, so the drag end settles instead.
      if (strongSelf->_isPresented && !strongSelf.isBeingDismissed) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
          if (!strongSelf->_isDragging) {
            [strongSelf settleAtDetentIndex:strongSelf.currentDetentIndex debug:@"transition end"];
          }
        });
      }
    }];
}

- (void)handleTransitionTick {
  // Also covers the interactive dismiss phase (finger down) — layout passes
  // are skipped while transitioning, so the tick owns position there too.
  CGFloat position = self.livePosition;

  if (self.isBeingDismissed) {
    // Hide blur at the end of dismiss to prevent UIVisualEffectView
    // from causing a flicker/flash at the bottom edge of the sheet.
    if (self.screenHeight - position < 1) {
      _blurView.alpha = 0;
    }
  }

  [self emitChangePositionDelegateWithPosition:position realtime:YES debug:@"transition"];
}

/**
 * The sheet is at rest at a detent: learn the resolver-vs-actual offset and
 * emit the settled position. Only valid when the presentedView frame is final
 * — never mid-drag or mid-animation, where learning would store a bogus offset.
 */
- (void)settleAtDetentIndex:(NSInteger)index debug:(NSString *)debug {
  // Don't learn while a child sits on top — the deck transform skews the
  // measured frame; the next unobstructed settle learns.
  if (self.presentedViewController == nil) {
    [self learnOffsetForDetentIndex:index];
    [self correctHingeOffsetForIndex:index];
  }

  [self emitChangePositionDelegateWithPosition:self.currentPosition realtime:NO debug:debug];
}

#pragma mark - Interactive Navigation Dismiss

- (void)beginInteractiveDismiss {
  if (_isInteractiveDismiss) {
    // A settle animation from a prior gesture is still running. Stop it and reset so
    // this gesture tracks from a clean state; its stale completion is ignored via the
    // generation check in animateInteractiveContainerToTransform.
    [_interactiveContainerView.layer removeAllAnimations];
    [self endInteractiveDismissState];
  }

  _interactiveGeneration += 1;
  _isInteractiveDismiss = YES;
  _interactiveStartPosition = self.currentPosition;
  _interactiveContainerView = self.sheet.containerView;

  // Emit position from the container's presentation layer for the whole gesture, so
  // both the direct-set drag and the settle animation report a live, smooth position.
  _interactivePositionLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(emitInteractivePosition)];
  _interactivePositionLink.preferredFrameRateRange = CAFrameRateRangeMake(60, 120, 120);
  [_interactivePositionLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)emitInteractivePosition {
  CALayer *presentation = _interactiveContainerView.layer.presentationLayer;
  CGFloat offset = presentation ? presentation.affineTransform.ty : 0;
  [self emitChangePositionDelegateWithPosition:_interactiveStartPosition + offset realtime:YES debug:@"nav swipe"];
}

// Translate the presentation container, not the sheet's presentedView (whose transform
// UISheetPresentationController owns for the floating-sheet inset). Only runs for undimmed
// sheets — a dimmed sheet's dimming view intercepts the edge-swipe so the pop never starts.
- (void)updateInteractiveDismiss:(CGFloat)progress {
  if (!_isInteractiveDismiss) {
    return;
  }
  CGFloat clamped = fmin(1, fmax(0, progress));
  CGFloat dy = clamped * (self.screenHeight - _interactiveStartPosition);
  _interactiveContainerView.transform = CGAffineTransformMakeTranslation(0, dy);
}

- (void)cancelInteractiveDismissWithDuration:(NSTimeInterval)duration {
  if (!_isInteractiveDismiss) {
    return;
  }
  [self animateInteractiveContainerToTransform:CGAffineTransformIdentity
                                      duration:duration
                          allowUserInteraction:YES
                                    completion:nil];
}

- (void)finishInteractiveDismissWithDuration:(NSTimeInterval)duration completion:(void (^)(void))completion {
  if (!_isInteractiveDismiss) {
    if (completion) {
      completion();
    }
    return;
  }
  // Leave the sheet translated off-screen; the caller tears it down non-animated
  // from here so there is no second slide.
  CGFloat dy = self.screenHeight - _interactiveStartPosition;
  [self animateInteractiveContainerToTransform:CGAffineTransformMakeTranslation(0, dy)
                                      duration:duration
                          allowUserInteraction:NO
                                    completion:completion];
}

- (void)animateInteractiveContainerToTransform:(CGAffineTransform)transform
                                      duration:(NSTimeInterval)duration
                          allowUserInteraction:(BOOL)allowUserInteraction
                                    completion:(void (^)(void))completion {
  UIView *container = _interactiveContainerView;
  NSUInteger generation = _interactiveGeneration;

  UIViewAnimationOptions options = UIViewAnimationOptionCurveEaseOut | UIViewAnimationOptionBeginFromCurrentState;
  if (allowUserInteraction) {
    options |= UIViewAnimationOptionAllowUserInteraction;
  }

  [UIView animateWithDuration:fmax(duration, 0.2)
    delay:0
    options:options
    animations:^{
      container.transform = transform;
    }
    completion:^(BOOL finished) {
      // A newer gesture superseded this settle and owns teardown now.
      if (generation != self->_interactiveGeneration) {
        return;
      }
      [self endInteractiveDismissState];
      if (completion) {
        completion();
      }
    }];
}

- (void)endInteractiveDismissState {
  _isInteractiveDismiss = NO;
  _interactiveContainerView = nil;
  _interactiveStartPosition = 0;
  [_interactivePositionLink invalidate];
  _interactivePositionLink = nil;
}

- (void)emitChangePositionDelegateWithPosition:(CGFloat)position realtime:(BOOL)realtime debug:(NSString *)debug {
  UIViewController *presented = self.presentedViewController;
  if (presented) {
    UIModalPresentationStyle style = presented.modalPresentationStyle;
    if (style == UIModalPresentationFullScreen || style == UIModalPresentationOverFullScreen ||
        style == UIModalPresentationCurrentContext || style == UIModalPresentationOverCurrentContext) {
      return;
    }
  }

  if (self.isPresented && !self.isBeingDismissed && !_isWillDismissEmitted && !_usesBackgroundEffects) {
    NSInteger index = [_detentCalculator backgroundIndexForPosition:position displayedIndex:_displayedBackgroundIndex];
    if (index != _displayedBackgroundIndex) {
      _displayedBackgroundIndex = index;
      [UIView animateWithDuration:0.2
                            delay:0
                          options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction
                       animations:^{
                         [self setupBackground];
                       }
                       completion:nil];
    }
  }

  TrueSheetPositionState state = {
    .position = position,
    .detent = [self interpolatedDetentForPosition:position],
    .index = [self interpolatedIndexForPosition:position],
  };

  // A child on top only pushes this sheet back, its detent stays.
  if (!presented) {
    _dimView.alpha = [self dimAlphaForPosition:position index:state.index];
  }

  // Settle (non-realtime) emits are authoritative and bypass the dedupe — a
  // learn right before them can correct the interpolated index by less than
  // the tolerance, and the corrected value must still reach JS.
  if (!realtime || !TrueSheetPositionStateEquals(_lastEmittedPositionState, state)) {
    _lastEmittedPositionState = state;

    [self.delegate viewControllerDidChangePosition:state.index
                                          position:state.position
                                            detent:state.detent
                                          realtime:realtime];
  }
}

- (void)learnOffsetForDetentIndex:(NSInteger)index {
  if (_keyboardSheetGrown || _minimizedKeyboardOverlap > 0) {
    return;
  }
  [_detentCalculator learnOffsetForDetentIndex:index];
}

- (void)setKeyboardSheetGrown:(BOOL)keyboardSheetGrown {
  BOOL wasGrown = _keyboardSheetGrown;
  _keyboardSheetGrown = keyboardSheetGrown;

  // Settles are skipped or measure a mid-animation frame while the keyboard
  // has the sheet grown (e.g. a drag-end during the shrink-back) — re-settle
  // at the resting detent once the keyboard is fully away.
  if (wasGrown && !keyboardSheetGrown && self.isPresented && !_isDragging) {
    [self settleAtDetentIndex:self.currentDetentIndex debug:@"keyboard settled"];
  }
}

- (BOOL)findSegmentForPosition:(CGFloat)position outIndex:(NSInteger *)outIndex outProgress:(CGFloat *)outProgress {
  return [_detentCalculator findSegmentForPosition:position outIndex:outIndex outProgress:outProgress];
}

- (CGFloat)interpolatedIndexForPosition:(CGFloat)position {
  return [_detentCalculator interpolatedIndexForPosition:position];
}

- (CGFloat)interpolatedDetentForPosition:(CGFloat)position {
  return [_detentCalculator interpolatedDetentForPosition:position];
}

- (CGFloat)detentValueForIndex:(NSInteger)index {
  return [_detentCalculator detentValueForIndex:index];
}

#pragma mark - Hinge

/**
 * Bottom edge (window coordinates) of an active horizontal fold, or 0 when the
 * device isn't in tabletop. The division region is only active while the hinge
 * is partially open, so this also excludes flat and closed postures.
 */
- (CGFloat)tabletopHingeEdge {
#if RNTS_IPHONE_OS_VERSION_AVAILABLE(27_1)
  if (@available(iOS 27.1, *)) {
    UIWindow *window = self.hostWindow;
    for (UIViewReservedRegion *region in [window reservedRegionsOfKind:[UIViewReservedRegionKind divisionRegionKind]]) {
      CGRect frame = region.frame;
      if (region.isActive && frame.size.width > frame.size.height) {
        return CGRectGetMaxY(frame);
      }
    }
  }
#endif
  return 0;
}

/**
 * Gap between a hinge-placed detent's resolved height and the sheet's actual top
 * edge: UIKit adds the bottom safe area, plus the floating sheet's inset. Every
 * hinge-placed detent rests at the same height, so they share one offset — the
 * first settle at the hinge learns it.
 */
- (CGFloat)hingeOffsetForHeight:(CGFloat)height {
  if (_hingeOffset > 0) {
    return _hingeOffset;
  }

  return [self bottomSafeAreaForHeight:height] + TrueSheetFloatingSheetInset;
}

// A hinge-placed detent resolved with an off estimate lands a few points off
// the hinge — re-resolve once the settle has learned the real offset.
- (void)correctHingeOffsetForIndex:(NSInteger)index {
  NSNumber *usedOffset = _hingeOffsets[@(index)];
  if (!usedOffset || _hingeCorrections >= 2) {
    return;
  }

  CGFloat learnedOffset = [_detentCalculator learnedOffsetForIndex:index];
  if (learnedOffset == 0 || fabs(learnedOffset - usedOffset.doubleValue) <= 1) {
    return;
  }

  _hingeOffset = learnedOffset;
  _hingeCorrections++;
  dispatch_async(dispatch_get_main_queue(), ^{
    [self invalidateDetentsAnimated];
  });
}

- (void)invalidateDetentsAnimated {
  if (@available(iOS 16.0, *)) {
    [self.sheet animateChanges:^{
      self->_pendingContentSizeChange = YES;
      [self.sheet invalidateDetents];
    }];
  }
}

/**
 * Re-resolves hinge-placed detents when the posture changes, and runs 'snap':
 * entering tabletop moves the sheet to the hinge detent, leaving it restores the
 * previous detent if the sheet is still on the hinge. The posture a presentation
 * starts in only records state, so presenting while already in tabletop doesn't
 * jump the sheet. A change while presenting, dismissing, or dragging stays
 * pending until the sheet is at rest again.
 */
- (void)updateHingeState {
  NSInteger hingeIndex = self.foldOptions.hingeDetentIndex;
  if (hingeIndex < 0 && self.foldOptions.hingeBehavior == TrueSheetViewHingeBehavior::None) {
    return;
  }

  // Covered by a full-screen presentation, the sheet has no window to read the posture from
  if (!self.viewIfLoaded.window) {
    return;
  }

  CGFloat edge = [self tabletopHingeEdge];
  if (!_hingeStateKnown) {
    _hingeStateKnown = YES;
    _hingeEdge = edge;
    return;
  }

  if (!self.isPresented || self.isBeingDismissed || _isDragging || fabs(edge - _hingeEdge) < 0.5) {
    return;
  }

  BOOL entered = edge > 0 && _hingeEdge == 0;
  BOOL left = edge == 0 && _hingeEdge > 0;
  _hingeEdge = edge;
  _hingeOffset = 0;
  _hingeCorrections = 0;

  NSInteger targetIndex = -1;
  NSInteger detentCount = (NSInteger)self.detents.count;
  BOOL snaps =
    self.foldOptions.hingeBehavior == TrueSheetViewHingeBehavior::Snap && hingeIndex >= 0 && hingeIndex < detentCount;
  if (entered && snaps) {
    _hingeRestoreIndex = self.currentDetentIndex;
    targetIndex = hingeIndex;
  } else if (left && _hingeRestoreIndex >= 0) {
    // Keep a detent the user picked while folded
    if (snaps && self.currentDetentIndex == hingeIndex) {
      targetIndex = MIN(_hingeRestoreIndex, detentCount - 1);
    }
    _hingeRestoreIndex = -1;
  }

  // A resize settles through the pending detent change
  BOOL resizes = targetIndex >= 0 && targetIndex != self.activeDetentIndex;

  if (@available(iOS 16.0, *)) {
    [self.sheet animateChanges:^{
      [self.sheet invalidateDetents];
      if (resizes) {
        [self resizeToDetentIndex:targetIndex];
      }
    }];
  }

  // UIKit often re-resolves detents for the posture change on its own before
  // this runs, so the invalidation above triggers no layout pass to settle in.
  // Settle once the frame is final, same as a pending detent change.
  if (!resizes) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
      if (self.isPresented && !self.isBeingDismissed && !self->_isDragging && !self->_isTransitioning) {
        [self settleAtDetentIndex:self.currentDetentIndex debug:@"hinge"];
      }
    });
  }
}

#pragma mark - Sheet Configuration

/**
 * Applies a content/header/footer/peek size change to the already-built
 * detents. Auto and peek detents resolve lazily from snapshots, so this only
 * refreshes the snapshots and invalidates — never reassigns `sheet.detents`,
 * which would force UIKit to re-layout the whole presentation stack (visibly
 * perturbing a sheet behind this one).
 */
- (void)setupSheetDetentsForSizeChange {
  if (@available(iOS 16.0, *)) {
    CGFloat autoHeight = [_detentCalculator autoHeightForKeyboardHeight:_keyboardHeight] - [self autoDetentBottomInset];
    CGFloat peekHeight = [_detentCalculator peekHeight] - [self peekDetentBottomInset];

    if (fabs(autoHeight - _autoDetentHeight) < 0.5 && fabs(peekHeight - _peekDetentHeight) < 0.5) {
      return;
    }

    _autoDetentHeight = autoHeight;
    _peekDetentHeight = peekHeight;

    [self invalidateDetentsAnimated];
  }
  // iOS 15: detents are fixed medium/large — size changes can't affect them.
}

// Re-resolves the detents in place, e.g. when an input to the resolver
// changes after UIKit has already laid out the sheet.
- (void)invalidateDetents {
  if (@available(iOS 16.0, *)) {
    [self.sheet animateChanges:^{
      [self.sheet invalidateDetents];
    }];
  }
}

- (void)setupSheetDetentsForDetentsChange {
  _pendingDetentsChange = YES;
  [self setupSheetDetents];
}

- (void)setupSheetDetents {
  UISheetPresentationController *sheet = self.sheet;
  if (!sheet) {
    RCTLogError(@"TrueSheet: sheetPresentationController is nil in setupSheetDetents");
    return;
  }

  NSMutableArray<UISheetPresentationControllerDetent *> *detents = [NSMutableArray array];
  [_detentCalculator clearResolvedHeights];
  _hingeCorrections = 0;

  _autoDetentHeight = [_detentCalculator autoHeightForKeyboardHeight:_keyboardHeight] - [self autoDetentBottomInset];
  _peekDetentHeight = [_detentCalculator peekHeight] - [self peekDetentBottomInset];

  for (NSInteger index = 0; index < self.detents.count; index++) {
    id detent = self.detents[index];
    UISheetPresentationControllerDetent *sheetDetent = [self detentForValue:detent atIndex:index];
    [detents addObject:sheetDetent];
  }

  [_detentCalculator setDetentCount:self.detents.count];
  _usesBackgroundEffects = [self canUseBackgroundEffects:detents];
#if RNTS_IPHONE_OS_VERSION_AVAILABLE(26_1) && !TARGET_OS_MACCATALYST
  if (@available(iOS 26.1, *)) {
    if (_usesBackgroundEffects) {
      for (NSInteger index = 0; index < detents.count; index++) {
        NSDictionary *entry = [self backgroundForIndex:index];
        auto blur = entry[@"blur"] ? static_cast<TrueSheetViewBackgroundBlur>([entry[@"blur"] intValue])
                                   : TrueSheetViewBackgroundBlur::None;
        detents[index].backgroundEffect = [self backgroundEffectForColor:entry[@"color"] blur:blur];
      }
    }
  }
#endif

  sheet.detents = detents;

  if ([self useCustomDimming]) {
    sheet.largestUndimmedDetentIdentifier = sheet.detents.lastObject.identifier;
  } else if ([self isDimmedAtEveryDetent]) {
    sheet.largestUndimmedDetentIdentifier = nil;
  } else {
    sheet.largestUndimmedDetentIdentifier = UISheetPresentationControllerDetentIdentifierLarge;

    if (@available(iOS 16.0, *)) {
      if (self.dimmed && self.dimmedDetentIndex) {
        NSInteger dimmedIdx = [self.dimmedDetentIndex integerValue];
        if (dimmedIdx > 0 && dimmedIdx - 1 < sheet.detents.count) {
          sheet.largestUndimmedDetentIdentifier = sheet.detents[dimmedIdx - 1].identifier;
        } else if (sheet.detents.lastObject) {
          sheet.largestUndimmedDetentIdentifier = sheet.detents.lastObject.identifier;
        }
      } else if (sheet.detents.lastObject) {
        sheet.largestUndimmedDetentIdentifier = sheet.detents.lastObject.identifier;
      }
    }
  }
}

- (UISheetPresentationControllerDetent *)detentForValue:(id)detent atIndex:(NSInteger)index {
  if (![detent isKindOfClass:[NSNumber class]]) {
    return [UISheetPresentationControllerDetent mediumDetent];
  }

  CGFloat value = [detent doubleValue];

  // Auto/peek resolve from height snapshots — refreshed only in
  // setupSheetDetents and setupSheetDetentsForSizeChange — so size changes are
  // picked up on invalidation, while UIKit's spontaneous re-resolutions (e.g.
  // while a child sheet dismisses) read a stable value.
  if (value == -1) {
    if (@available(iOS 16.0, *)) {
      return [self customDetentWithIdentifier:@"custom-auto"
                                      atIndex:index
                                  heightBlock:^CGFloat {
                                    return self->_autoDetentHeight;
                                  }];
    } else {
      return [UISheetPresentationControllerDetent mediumDetent];
    }
  }

  if (value == -2) {
    if (@available(iOS 16.0, *)) {
      return [self customDetentWithIdentifier:@"custom-peek"
                                      atIndex:index
                                  heightBlock:^CGFloat {
                                    return self->_peekDetentHeight;
                                  }];
    } else {
      return [UISheetPresentationControllerDetent mediumDetent];
    }
  }

  if (value <= 0 || value > 1) {
    RCTLogError(@"TrueSheet: detent fraction (%f) must be between 0 and 1", value);
    return [UISheetPresentationControllerDetent mediumDetent];
  }

  if (@available(iOS 16.0, *)) {
    NSString *detentId = [NSString stringWithFormat:@"custom-%f", value];
    // Resolve lazily — detents are built before presentation (no window yet), and
    // UIKit re-resolves on container size changes (rotation, windowed iPad resize).
    return [self customDetentWithIdentifier:detentId
                                    atIndex:index
                                heightBlock:^CGFloat {
                                  return value * self.screenHeight;
                                }];
  } else if (value >= 0.5) {
    return [UISheetPresentationControllerDetent largeDetent];
  } else {
    return [UISheetPresentationControllerDetent mediumDetent];
  }
}

- (UISheetPresentationControllerDetent *)customDetentWithIdentifier:(NSString *)identifier
                                                            atIndex:(NSInteger)index
                                                        heightBlock:(CGFloat (^)(void))heightBlock
  API_AVAILABLE(ios(16.0)) {
  return [UISheetPresentationControllerDetent
    customDetentWithIdentifier:identifier
                      resolver:^CGFloat(id<UISheetPresentationControllerDetentResolutionContext> context) {
                        CGFloat maxDetentValue = context.maximumDetentValue;
                        self->_detentCalculator.maxDetentHeight = maxDetentValue;

                        CGFloat height = heightBlock();
                        CGFloat bottomAdjustment = [self detentBottomAdjustmentForHeight:height];
                        CGFloat maxValue = self.maxContentHeight
                                             ? fmin(maxDetentValue, [self.maxContentHeight floatValue])
                                             : maxDetentValue;

                        CGFloat adjustedHeight = height - bottomAdjustment;
                        NSInteger lastIndex = (NSInteger)self.detents.count - 1;

                        // Tabletop: the hinge detent rests on the hinge, and 'avoid'/'snap'
                        // cap every detent there.
                        BOOL avoidsHinge = self.foldOptions.hingeBehavior != TrueSheetViewHingeBehavior::None;
                        NSInteger hingeIndex = self.foldOptions.hingeDetentIndex;
                        BOOL hasHingeDetent = hingeIndex >= 0 && hingeIndex <= lastIndex;
                        CGFloat hingeEdge = (hasHingeDetent || avoidsHinge) ? [self tabletopHingeEdge] : 0;
                        CGFloat hingeOffset = 0;
                        CGFloat hingeHeight = 0;
                        if (hingeEdge > 0) {
                          CGFloat panelHeight = self.screenHeight - hingeEdge;
                          hingeOffset = [self hingeOffsetForHeight:panelHeight];
                          hingeHeight = panelHeight - hingeOffset;
                          if (hasHingeDetent) {
                            // Lower detents stay below the hinge detent and higher ones above
                            // it, so the detents keep their order
                            CGFloat hingeDetentHeight =
                              avoidsHinge ? hingeHeight - (lastIndex - hingeIndex) : hingeHeight;
                            if (index == hingeIndex) {
                              adjustedHeight = hingeHeight;
                            } else if (index < hingeIndex) {
                              adjustedHeight = fmin(adjustedHeight, hingeDetentHeight - (hingeIndex - index));
                            } else {
                              adjustedHeight = fmax(adjustedHeight, hingeDetentHeight + (index - hingeIndex));
                            }
                          }
                          if (avoidsHinge) {
                            maxValue = fmin(maxValue, hingeHeight);
                          }
                        }

                        // Only the last detent may occupy the full maximum. Two detents
                        // resolving to the same height (e.g. a capped auto and 1) make
                        // UIKit skip the stack's deck animation when presenting a child
                        // sheet and snap the sheet behind into place instead.
                        if (adjustedHeight >= maxValue && index < lastIndex) {
                          maxValue -= lastIndex - index;
                        }

                        CGFloat resolved = fmin(adjustedHeight, maxValue);

                        // Detents within the collapse spacing of the hinge are hinge-placed.
                        // They rest with the hinge offset, so position events map them right
                        // before the first settle there.
                        if (hingeHeight > 0 && fabs(resolved - hingeHeight) <= lastIndex + 0.5) {
                          self->_hingeOffsets[@(index)] = @(hingeOffset);
                          [self->_detentCalculator assumeOffset:hingeOffset forIndex:index];
                        } else {
                          [self->_hingeOffsets removeObjectForKey:@(index)];
                        }

                        NSMutableArray *heights = self->_detentCalculator.resolvedDetentHeights;
                        if (heights && index >= 0 && index < (NSInteger)heights.count) {
                          heights[index] = @(resolved);
                        }

                        // Recorded uncompensated above: UIKit adds the overlap back on
                        // top. A sheet shorter than the overlap still grows by the rest.
                        return fmax(resolved - self.minimizedKeyboardOverlap, 0);
                      }];
}

- (UISheetPresentationControllerDetentIdentifier)detentIdentifierForIndex:(NSInteger)index {
  UISheetPresentationController *sheet = self.sheet;
  if (!sheet) {
    RCTLogError(@"TrueSheet: sheetPresentationController is nil in detentIdentifierForIndex");
    return UISheetPresentationControllerDetentIdentifierMedium;
  }

  UISheetPresentationControllerDetentIdentifier identifier = UISheetPresentationControllerDetentIdentifierMedium;
  if (index >= 0 && index < (NSInteger)sheet.detents.count) {
    UISheetPresentationControllerDetent *detent = sheet.detents[index];
    if (@available(iOS 16.0, *)) {
      identifier = detent.identifier;
    } else {
      if (detent == [UISheetPresentationControllerDetent largeDetent]) {
        identifier = UISheetPresentationControllerDetentIdentifierLarge;
      }
    }
  }

  return identifier;
}

- (void)applyActiveDetent {
  if (!self.sheet) {
    RCTLogError(@"TrueSheet: sheetPresentationController is nil in applyActiveDetent");
    return;
  }

  NSInteger detentCount = _detents.count;
  if (detentCount == 0)
    return;

  NSInteger clampedIndex = _activeDetentIndex;
  if (clampedIndex < 0) {
    clampedIndex = 0;
  } else if (clampedIndex >= detentCount) {
    clampedIndex = detentCount - 1;
  }

  if (clampedIndex != _activeDetentIndex) {
    _activeDetentIndex = clampedIndex;
  }

  UISheetPresentationControllerDetentIdentifier identifier = [self detentIdentifierForIndex:clampedIndex];
  if (identifier) {
    self.sheet.selectedDetentIdentifier = identifier;
  }
}

- (void)setupActiveDetentWithIndex:(NSInteger)index {
  _activeDetentIndex = index;
  _displayedBackgroundIndex = index;
  [self setupBackground];
  [self applyActiveDetent];
}

- (void)resizeToDetentIndex:(NSInteger)index {
  if (index == _activeDetentIndex) {
    return;
  }

  _pendingDetentIndex = index;
  _activeDetentIndex = index;
  [self applyActiveDetent];
}

- (BOOL)canUseBackgroundEffects:(NSArray<UISheetPresentationControllerDetent *> *)detents {
#if RNTS_IPHONE_OS_VERSION_AVAILABLE(26_1) && !TARGET_OS_MACCATALYST
  if (@available(iOS 26.1, *)) {
    // Some 26.1 builds omit setters declared in the SDK.
    if (self.isDesignCompatibilityMode || ![self.sheet respondsToSelector:@selector(setBackgroundEffect:)]) {
      return NO;
    }
    for (UISheetPresentationControllerDetent *detent in detents) {
      if (![detent respondsToSelector:@selector(setBackgroundEffect:)]) {
        return NO;
      }
    }
    return YES;
  }
#endif
  return NO;
}

- (NSDictionary *)backgroundForIndex:(NSInteger)index {
  return index >= 0 && index < self.detentBackgrounds.count ? self.detentBackgrounds[index] : nil;
}

#if RNTS_IPHONE_OS_VERSION_AVAILABLE(26_1) && !TARGET_OS_MACCATALYST
- (UIVisualEffect *)backgroundEffectForColor:(UIColor *)color
                                        blur:(TrueSheetViewBackgroundBlur)blur API_AVAILABLE(ios(26.1)) {
  if (blur != TrueSheetViewBackgroundBlur::None) {
    return [UIBlurEffect effectWithStyle:[BlurUtil blurEffectStyleFromEnum:blur]];
  }
  return color ? [UIColorEffect effectWithColor:color] : nil;
}
#endif

- (void)setupBackground {
#if RNTS_IPHONE_OS_VERSION_AVAILABLE(26_1) && !TARGET_OS_MACCATALYST
  if (@available(iOS 26.1, *)) {
    if (_usesBackgroundEffects) {
      self.sheet.backgroundEffect = [self backgroundEffectForColor:self.backgroundColor blur:self.backgroundBlur];
      self.view.backgroundColor = nil;
      _blurView.hidden = YES;
      _blurView.backgroundBlur = TrueSheetViewBackgroundBlur::None;
      [_blurView applyBlurEffect];
      return;
    }
  }
#endif

  NSDictionary *entry = [self backgroundForIndex:_displayedBackgroundIndex];
  BOOL hasEntry = entry[@"color"] || entry[@"blur"];
  UIColor *color = hasEntry ? entry[@"color"] : self.backgroundColor;
  auto effectiveBackgroundBlur =
    hasEntry ? (entry[@"blur"] ? static_cast<TrueSheetViewBackgroundBlur>([entry[@"blur"] intValue])
                               : TrueSheetViewBackgroundBlur::None)
             : self.backgroundBlur;
  if (@available(iOS 26.0, *)) {
    // iOS 26+ has default liquid glass effect
  } else if (effectiveBackgroundBlur == TrueSheetViewBackgroundBlur::None && !color) {
    effectiveBackgroundBlur = TrueSheetViewBackgroundBlur::SystemMaterial;
  }

  BOOL hasBlur = effectiveBackgroundBlur != TrueSheetViewBackgroundBlur::None;

  _blurView.hidden = NO;
  _blurView.backgroundBlur = effectiveBackgroundBlur;
  [_blurView applyBlurEffect];

  self.view.backgroundColor = hasBlur ? nil : color;
}

- (void)setupGrabber {
  BOOL showGrabber = self.grabber && self.draggable;

  if (self.grabberOptions) {
    self.sheet.prefersGrabberVisible = NO;

    GrabberOptions *options = self.grabberOptions;
    _grabberView.accessibilityOptions = self.accessibilityOptions;
    _grabberView.grabberWidth = options.width;
    _grabberView.grabberHeight = options.height;
    _grabberView.topMargin = options.topMargin;
    _grabberView.cornerRadius = options.cornerRadius;
    _grabberView.color = options.color;
    _grabberView.adaptive = @(options.adaptive);
    [_grabberView applyConfiguration];
    _grabberView.hidden = !showGrabber;

    __weak __typeof(self) weakSelf = self;
    _grabberView.onTap = ^{
      [weakSelf handleGrabberTap];
    };
    _grabberView.onIncrement = ^{
      __strong __typeof(weakSelf) strongSelf = weakSelf;
      if (!strongSelf)
        return;
      NSInteger current = strongSelf.currentDetentIndex;
      NSInteger count = strongSelf->_detents.count;
      if (current >= 0 && current < count - 1) {
        [strongSelf.sheet animateChanges:^{
          [strongSelf resizeToDetentIndex:current + 1];
        }];
      }
    };
    _grabberView.onDecrement = ^{
      __strong __typeof(weakSelf) strongSelf = weakSelf;
      if (!strongSelf)
        return;
      NSInteger current = strongSelf.currentDetentIndex;
      if (current > 0) {
        [strongSelf.sheet animateChanges:^{
          [strongSelf resizeToDetentIndex:current - 1];
        }];
      } else if (strongSelf.dismissible) {
        [strongSelf.presentingViewController dismissViewControllerAnimated:YES completion:nil];
      } else {
        [strongSelf.delegate viewControllerDidAttemptDismiss];
      }
    };

    [self.view bringSubviewToFront:_grabberView];
  } else {
    self.sheet.prefersGrabberVisible = showGrabber;
    _grabberView.hidden = YES;
    _grabberView.onTap = nil;
    _grabberView.onIncrement = nil;
    _grabberView.onDecrement = nil;
  }

  [self refreshAccessibilityContainer];
}

- (void)handleGrabberTap {
  NSInteger detentCount = _detents.count;
  if (detentCount == 0)
    return;

  NSInteger currentIndex = self.currentDetentIndex;
  if (currentIndex < 0)
    return;

  NSInteger nextIndex = (currentIndex + 1) % detentCount;
  if (nextIndex == 0 && detentCount == 1) {
    if (self.dismissible) {
      [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
    } else {
      [self.delegate viewControllerDidAttemptDismiss];
    }
  } else {
    [self.sheet animateChanges:^{
      [self resizeToDetentIndex:nextIndex];
    }];
  }
}

- (BOOL)isAnchored {
  return self.placement == TrueSheetViewPlacement::Leading || self.placement == TrueSheetViewPlacement::Trailing;
}

#if RNTS_IPHONE_OS_VERSION_AVAILABLE(27_0)
- (UISheetPresentationControllerPlacement)preferredPlacement API_AVAILABLE(ios(27.0)) {
  switch (self.placement) {
    case TrueSheetViewPlacement::Leading:
      return UISheetPresentationControllerPlacementLeading;
    case TrueSheetViewPlacement::Center:
      return UISheetPresentationControllerPlacementCenter;
    case TrueSheetViewPlacement::Trailing:
      return UISheetPresentationControllerPlacementTrailing;
    case TrueSheetViewPlacement::Automatic:
      return UISheetPresentationControllerPlacementAutomatic;
  }
}
#endif

- (void)setupAnchorViewInView:(UIView *)parentView {
  if (!parentView)
    return;

  [_anchorView removeFromSuperview];
  _anchorView = nil;

#if RNTS_IPHONE_OS_VERSION_AVAILABLE(27_0)
  // iOS 27 exposes native placement. `sourceView` must stay nil since it overrides `preferredPlacement`.
  if (@available(iOS 27.0, *)) {
    if ([self.sheetPresentationController respondsToSelector:@selector(setPreferredPlacement:)]) {
      self.sheetPresentationController.sourceView = nil;
      self.sheetPresentationController.preferredPlacement = [self preferredPlacement];
      return;
    }
  }
#endif

  // Pre-27 has no explicit center, so `center` falls back to the system default like `automatic`.
  if (!self.isAnchored) {
    self.sheetPresentationController.sourceView = nil;
    return;
  }

  _anchorView = [[UIView alloc] init];
  _anchorView.userInteractionEnabled = NO;
  _anchorView.translatesAutoresizingMaskIntoConstraints = NO;
  [parentView addSubview:_anchorView];

  NSLayoutAnchor *horizontalAnchor =
    self.placement == TrueSheetViewPlacement::Trailing ? parentView.trailingAnchor : parentView.leadingAnchor;

  [NSLayoutConstraint activateConstraints:@[
    [_anchorView.bottomAnchor constraintEqualToAnchor:parentView.bottomAnchor],
    [horizontalAnchor constraintEqualToAnchor:_anchorView.leadingAnchor],
  ]];

  self.sheetPresentationController.sourceView = _anchorView;
}

- (void)setupSheetSizing {
  UISheetPresentationController *sheet = self.sheet;
  if (!sheet)
    return;

  // `presentation` is absolute on the form side: 'form' always renders a
  // centered form sheet and ignores `maxContentWidth`. For 'page' with a
  // custom `maxContentWidth`, prefersPageSizing has to flip to NO since
  // `widthFollowsPreferredContentSizeWhenEdgeAttached` only takes effect
  // when the sheet is edge-attached (Apple API constraint).
  BOOL formSheet = self.presentation == facebook::react::TrueSheetViewPresentation::Form;
  BOOL hasMaxWidth = self.maxContentWidth != nil && !formSheet;

  if (@available(iOS 17.0, *)) {
    sheet.prefersPageSizing = !formSheet && !hasMaxWidth;
  }

  sheet.widthFollowsPreferredContentSizeWhenEdgeAttached = hasMaxWidth;

  if (hasMaxWidth) {
    CGFloat height = self.maxContentHeight ? [self.maxContentHeight floatValue] : self.screenHeight;
    self.preferredContentSize = CGSizeMake([self.maxContentWidth floatValue], height);
  } else {
    self.preferredContentSize = CGSizeZero;
  }
}

- (void)setupSheetProps {
  UISheetPresentationController *sheet = self.sheet;
  if (!sheet)
    return;

  sheet.delegate = self;
  sheet.prefersEdgeAttachedInCompactHeight = YES;
  sheet.prefersScrollingExpandsWhenScrolledToEdge = self.draggable && self.scrollingExpandsSheet;

  if (self.cornerRadius) {
    sheet.preferredCornerRadius = [self.cornerRadius floatValue];
  } else {
    sheet.preferredCornerRadius = UISheetPresentationControllerAutomaticDimension;
  }

  [self setupBackground];
  [self setupGrabber];

  // Dim props changed while presented. A hidden custom dim stays until dismiss;
  // at alpha 0 it no longer takes touches.
  if (_isPresented) {
    [self setupDimView];
    _dimView.alpha = [self dimAlphaForIndex:self.currentDetentIndex];
  }
}

#pragma mark - UISheetPresentationControllerDelegate

- (BOOL)presentationControllerShouldDismiss:(UIPresentationController *)presentationController {
  // A sheet that can't be dragged can't be swiped away either, including by
  // pulling down its scroll view: refuse a dismissal while any pan is under
  // way, and keep the one from a tap outside the sheet. Reset on every call:
  // UIKit skips didAttemptToDismiss for a short pull.
  _refusedPanDismiss =
    self.dismissible && !self.draggable && [self hasActivePanInView:presentationController.containerView];
  return self.dismissible && !_refusedPanDismiss;
}

- (BOOL)hasActivePanInView:(UIView *)view {
  if (!view) {
    return NO;
  }
  for (UIGestureRecognizer *recognizer in view.gestureRecognizers ?: @[]) {
    if ([recognizer isKindOfClass:[UIPanGestureRecognizer class]] &&
        (recognizer.state == UIGestureRecognizerStateBegan || recognizer.state == UIGestureRecognizerStateChanged)) {
      return YES;
    }
  }
  for (UIView *subview in view.subviews) {
    if ([self hasActivePanInView:subview]) {
      return YES;
    }
  }
  return NO;
}

// UIKit calls this after shouldDismiss returns NO — the sheet has already
// bounced back, so JS can confirm and dismiss programmatically (Apple's
// unsaved-changes pattern).
- (void)presentationControllerDidAttemptToDismiss:(UIPresentationController *)presentationController {
  // A swipe refused only because the sheet can't be dragged isn't an attempt
  // to dismiss a non-dismissible sheet.
  if (_refusedPanDismiss) {
    _refusedPanDismiss = NO;
    return;
  }
  [self.delegate viewControllerDidAttemptDismiss];
}

- (void)sheetPresentationControllerDidChangeSelectedDetentIdentifier:
  (UISheetPresentationController *)sheetPresentationController {
  dispatch_async(dispatch_get_main_queue(), ^{
    NSInteger index = self.currentDetentIndex;
    if (index >= 0) {
      CGFloat detent = [self detentValueForIndex:index];
      [self.delegate viewControllerDidChangeDetent:index position:self.currentPosition detent:detent];
    }
  });
}

#pragma mark - RNSDismissibleModalProtocol

#if RNS_DISMISSIBLE_MODAL_PROTOCOL_AVAILABLE
- (BOOL)isDismissible {
  return NO;
}

- (UIViewController *)newPresentingViewController {
  UIViewController *topmost = self;
  while (topmost.presentedViewController != nil && !topmost.presentedViewController.isBeingDismissed &&
         [topmost.presentedViewController isKindOfClass:[TrueSheetViewController class]]) {
    topmost = topmost.presentedViewController;
  }
  return topmost;
}
#endif

@end

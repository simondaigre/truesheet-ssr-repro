import React from 'react';
import type { DrawerDirection, KeyboardViewport } from './types';

export interface DragEvent {
  target: EventTarget;
  pageX: number;
  pageY: number;
  pointerType: string;
}

interface DrawerContextValue {
  drawerRef: React.RefObject<HTMLDivElement | null>;
  overlayRef: React.RefObject<HTMLDivElement | null>;
  onPress: (event: React.PointerEvent<HTMLDivElement>) => void;
  onRelease: (event: React.PointerEvent<HTMLDivElement> | null) => void;
  onDrag: (event: React.PointerEvent<HTMLDivElement>) => void;
  onTouchDrag: (event: DragEvent, pointerEvent?: React.PointerEvent<HTMLDivElement>) => void;
  onTouchRelease: (
    event: DragEvent | null,
    pointerEvent?: React.PointerEvent<HTMLDivElement>
  ) => void;
  onNestedDrag: (event: React.PointerEvent<HTMLDivElement>, percentageDragged: number) => void;
  onNestedOpenChange: (o: boolean) => void;
  onNestedRelease: (event: React.PointerEvent<HTMLDivElement>, open: boolean) => void;
  dismissible: boolean;
  onDismissAttempt?: () => void;
  isOpen: boolean;
  isDragging: boolean;
  keyboardIsOpen: React.MutableRefObject<boolean>;
  snapPointsOffset: number[] | null;
  getSnapPointCssOffsetAt: (index: number) => string;
  snapPoints?: (number | string)[] | null;
  activeSnapPointIndex?: number | null;
  fadeFromIndex?: number;
  modal: boolean;
  shouldFade: boolean;
  activeSnapPoint?: number | string | null;
  setActiveSnapPoint: (o: number | string | null) => void;
  closeDrawer: () => void;
  openProp?: boolean;
  onOpenChange?: (o: boolean) => void;
  direction: DrawerDirection;
  shouldScaleBackground: boolean;
  setBackgroundColorOnScale: boolean;
  noBodyStyles: boolean;
  handleOnly?: boolean;
  container?: HTMLElement | null;
  autoFocus?: boolean;
  shouldAnimate?: React.RefObject<boolean>;
  initialAnimated: boolean;
  hasPresented: React.RefObject<boolean>;
  onPositionChangeRef: React.RefObject<((position: number) => void) | undefined>;
  setContentHeight: (height: number) => void;
  detached: boolean;
  detachedOffset: number;
  detachedRadius: number;
  detachedWrapperStyle?: React.CSSProperties;
  keyboardViewport?: KeyboardViewport;
}

export const DrawerContext = React.createContext<DrawerContextValue>({
  drawerRef: { current: null },
  overlayRef: { current: null },
  onPress: () => {},
  onRelease: () => {},
  onDrag: () => {},
  onTouchDrag: () => {},
  onTouchRelease: () => {},
  onNestedDrag: () => {},
  onNestedOpenChange: () => {},
  onNestedRelease: () => {},
  openProp: undefined,
  dismissible: false,
  isOpen: false,
  isDragging: false,
  keyboardIsOpen: { current: false },
  snapPointsOffset: null,
  getSnapPointCssOffsetAt: () => '0px',
  snapPoints: null,
  handleOnly: false,
  modal: false,
  shouldFade: false,
  activeSnapPoint: null,
  onOpenChange: () => {},
  setActiveSnapPoint: () => {},
  closeDrawer: () => {},
  direction: 'bottom',
  shouldAnimate: { current: true },
  initialAnimated: true,
  hasPresented: { current: false },
  shouldScaleBackground: false,
  setBackgroundColorOnScale: true,
  noBodyStyles: false,
  container: null,
  autoFocus: false,
  onPositionChangeRef: { current: undefined },
  setContentHeight: () => {},
  detached: false,
  detachedOffset: 0,
  detachedRadius: 0,
});

export const useDrawerContext = () => {
  const context = React.useContext(DrawerContext);
  if (!context) {
    throw new Error('useDrawerContext must be used within a Drawer.Root');
  }
  return context;
};
